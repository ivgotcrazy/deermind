/* ============================================================
   三端共享 Pinia store：证据账本 + 掌握度估计器(演示) + 政策引擎
   学生端 / 家长端 / 管理员端 共用同一份 mock 状态 → 联动演示
   算法（估计器公式 / 更新函数 / 信息增益 / 阈值校准）
   见《系统设计.md》——本文件仅做【演示规则】
   ============================================================ */
import { defineStore } from 'pinia'
import { ref } from 'vue'
import {
  type AttentionState,
  type EvidenceRecord,
  type EvidenceType,
  type KnowledgePoint,
  type LearningSpace,
  type MasteryState,
  type PolicyDecision,
  type RuleConfig,
  type StudentAccount,
  seedAttention,
  seedDecisions,
  seedEvidence,
  seedKps,
  seedRules,
  seedSpaces,
  seedStudents,
} from '@/data/sharedMock'

/* 演示权重：证据类型 → 权重（算法见系统设计） */
function demoWeight(type: EvidenceType, result: 'pass' | 'fail'): number {
  if (result === 'fail') return 0.25
  switch (type) {
    case 'variant':
      return 0.8 // 迁移题 = 高价值证据
    case 'feynman':
      return 0.55
    case 'practice':
      return 0.6
    case 'quiz':
      return 0.5
    case 'review':
      return 0.5
    case 'reading':
      return 0.4
    default:
      return 0.3
  }
}

function demoEstimate(state: MasteryState): number {
  switch (state) {
    case 'stable':
      return 92
    case 'short':
      return 78
    case 'learning':
      return 60
    default:
      return 0
  }
}

/* 演示估计器：单条证据后的状态迁移判定（产品规则见 PRD，公式见系统设计） */
function estimateState(
  kp: KnowledgePoint,
  type: EvidenceType,
  result: 'pass' | 'fail',
): MasteryState | null {
  if (result === 'fail') {
    // 单次错误不直接降级（PRD §5.4）→ 演示：仅高价值迁移失败回退一档
    if (type === 'variant' || type === 'review') {
      if (kp.state === 'stable') return 'short'
      if (kp.state === 'short') return 'learning'
    }
    return null
  }
  switch (type) {
    case 'variant':
      // 变式 = 即时迁移：LEARNING→SHORT；迁移题 = 高价值迁移：SHORT→STABLE
      if (kp.state === 'untouched') return 'learning'
      if (kp.state === 'learning') return 'short'
      if (kp.state === 'short') return 'stable'
      return null
    case 'review':
      return null // 间隔复习通过：状态不变，证据入账（演示）
    case 'feynman':
      // Teach-back 全要点：LEARNING 下作为重要支持证据 → SHORT（演示简化）
      if (kp.state === 'learning') return 'short'
      return null
    case 'practice':
    case 'quiz':
      if (kp.state === 'untouched') return 'learning'
      return null
    default:
      return null
  }
}

function demoReason(from: MasteryState, to: MasteryState, type: EvidenceType, kpName: string): string {
  if (from === to) {
    return `证据入账，状态保持【${label(from)}】；未达下一档阈值（演示），继续收集证据。`
  }
  switch (to) {
    case 'learning':
      return `首次有效证据（${kpName}），从【${label(from)}】进入【学习中】；UNKNOWN≠未掌握，静默推进。`
    case 'short':
      return `${type === 'feynman' ? 'Teach-back 全要点自述' : '变式（即时迁移）通过'}，证据充分 → 判定【短期掌握】；安排间隔复习 + 一道迁移题验证稳定性。`
    case 'stable':
      return `高价值迁移题通过，估计器达到 STABLE 阈值（演示 0.8）→ 判定【稳定掌握】；执行停止策略：不再花时间主动练习。`
    default:
      return '证据入账。'
  }
}

function demoAction(to: MasteryState): string {
  switch (to) {
    case 'learning':
      return '安排讲解 + 基础练习'
    case 'short':
      return '安排间隔复习(1/3/7天) + 高价值迁移题'
    case 'stable':
      return '停止该知识点主动练习（减负）'
    default:
      return '保持观察'
  }
}

function label(s: MasteryState): string {
  return ({ untouched: '未接触', learning: '学习中', short: '短期掌握', stable: '稳定掌握' } as Record<MasteryState, string>)[s]
}

let seq = 1000
const nextId = (p: string) => `${p}-${++seq}`

function nowTime(): string {
  const d = new Date()
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

export const useEvidenceStore = defineStore('evidence', () => {
  const kps = ref<KnowledgePoint[]>(JSON.parse(JSON.stringify(seedKps)) as KnowledgePoint[])
  const evidence = ref<EvidenceRecord[]>(JSON.parse(JSON.stringify(seedEvidence)) as EvidenceRecord[])
  const decisions = ref<PolicyDecision[]>(JSON.parse(JSON.stringify(seedDecisions)) as PolicyDecision[])
  const spaces = ref<LearningSpace[]>(JSON.parse(JSON.stringify(seedSpaces)) as LearningSpace[])
  const students = ref<StudentAccount[]>(JSON.parse(JSON.stringify(seedStudents)) as StudentAccount[])
  const rules = ref<RuleConfig>(JSON.parse(JSON.stringify(seedRules)) as RuleConfig)
  const attention = ref<AttentionState>(JSON.parse(JSON.stringify(seedAttention)) as AttentionState)

  function findKp(kpId: string): KnowledgePoint | undefined {
    return kps.value.find((k) => k.id === kpId)
  }

  /* 核心：写入证据 → 估计器判定 → 必要时生成决策 */
  function applyEvidence(
    kpId: string,
    type: EvidenceType,
    result: 'pass' | 'fail',
    source: string,
    note: string,
  ): MasteryState | null {
    const kp = findKp(kpId)
    if (!kp) return null

    evidence.value.push({
      id: nextId('e'),
      time: nowTime(),
      kpId,
      kpName: kp.name,
      type,
      result,
      weight: demoWeight(type, result),
      source,
      note,
    })

    const from = kp.state
    const to = estimateState(kp, type, result)
    if (to && to !== from) {
      kp.state = to
      kp.estimate = demoEstimate(to)
      kp.confidence = to === 'stable' ? 0.9 : to === 'short' ? 0.72 : 0.55
      kp.stability = to === 'stable' ? 0.9 : to === 'short' ? 0.5 : 0.3
      decisions.value.push({
        id: nextId('d'),
        time: nowTime(),
        kpId,
        kpName: kp.name,
        trigger: `${typeLabel(type)}${result === 'pass' ? '通过' : '未通过'} · ${source}`,
        action: demoAction(to),
        reason: demoReason(from, to, type, kp.name),
        fromState: from,
        toState: to,
      })
    } else {
      decisions.value.push({
        id: nextId('d'),
        time: nowTime(),
        kpId,
        kpName: kp.name,
        trigger: `${typeLabel(type)}${result === 'pass' ? '通过' : '未通过'} · ${source}`,
        action: '证据入账，状态不变',
        reason: demoReason(from, from, type, kp.name),
        fromState: from,
        toState: from,
      })
    }
    return to ?? from
  }

  function typeLabel(t: EvidenceType): string {
    return (
      {
        quiz: '检验',
        practice: '基础练习',
        variant: '变式',
        review: '间隔复习',
        feynman: 'Teach-back',
        reading: '读题训练',
        entry: '录入',
      } as Record<EvidenceType, string>
    )[t]
  }

  /* Attention Budget 消耗 */
  function spendProactiveAction() {
    attention.value.todayProactiveActions++
  }
  function spendReminder() {
    attention.value.todayReminders++
  }
  function addFocusMinutes(m: number) {
    attention.value.todayFocusMinutes += m
  }
  function markTodayDone() {
    attention.value.todayCompleted = true
  }

  function resetAll() {
    kps.value = JSON.parse(JSON.stringify(seedKps)) as KnowledgePoint[]
    evidence.value = JSON.parse(JSON.stringify(seedEvidence)) as EvidenceRecord[]
    decisions.value = JSON.parse(JSON.stringify(seedDecisions)) as PolicyDecision[]
    spaces.value = JSON.parse(JSON.stringify(seedSpaces)) as LearningSpace[]
    students.value = JSON.parse(JSON.stringify(seedStudents)) as StudentAccount[]
    rules.value = JSON.parse(JSON.stringify(seedRules)) as RuleConfig
    attention.value = JSON.parse(JSON.stringify(seedAttention)) as AttentionState
  }

  return {
    kps,
    evidence,
    decisions,
    spaces,
    students,
    rules,
    attention,
    findKp,
    applyEvidence,
    spendProactiveAction,
    spendReminder,
    addFocusMinutes,
    markTodayDone,
    resetAll,
  }
})
