/* ============================================================
   三端共享 mock 数据（学生端 / 家长端 / 管理员端 共用同一份状态）
   对齐 doc/产品设计.md v0.4.1（证据驱动的学习决策引擎）
   算法（估计器公式 / 信息增益 / 阈值校准）见《系统设计.md》
   本文件中的 estimate / confidence / stability 均为【演示值】
   ============================================================ */

export type MasteryState = 'untouched' | 'learning' | 'short' | 'stable'

export const STATE_LABEL: Record<MasteryState, string> = {
  untouched: '未接触',
  learning: '学习中',
  short: '短期掌握',
  stable: '稳定掌握',
}

export const STATE_ORDER: MasteryState[] = ['untouched', 'learning', 'short', 'stable']

export type EvidenceType =
  | 'quiz'
  | 'practice'
  | 'variant'
  | 'review'
  | 'feynman'
  | 'reading'
  | 'entry'

export const EVIDENCE_TYPE_LABEL: Record<EvidenceType, string> = {
  quiz: '检验',
  practice: '基础练习',
  variant: '变式 / 迁移题',
  review: '间隔复习',
  feynman: 'Teach-back 自述',
  reading: '读题训练',
  entry: '录入 / 观察',
}

export interface KnowledgePoint {
  id: string
  name: string
  domain: string
  important: boolean
  state: MasteryState
  estimate: number // 演示值：估计掌握概率（0-100）
  confidence: number // 演示值：置信度（0-1）
  stability: number // 演示值：稳定度（0-1）
  prerequisites: string[]
}

export interface EvidenceRecord {
  id: string
  time: string // 'HH:MM'
  kpId: string
  kpName: string
  type: EvidenceType
  result: 'pass' | 'fail'
  weight: number // 演示值：证据权重（0-1）
  source: string // 证据来源
  note: string
}

export interface PolicyDecision {
  id: string
  time: string
  kpId: string
  kpName: string
  trigger: string // 触发证据摘要
  action: string // 输出 Action
  reason: string // 决策理由（可解释性）
  fromState: MasteryState
  toState: MasteryState
}

export interface LearningSpace {
  id: string
  name: string
  studentName: string
  textbook: string
  progress: string
  boundKp: number
  trackedKp: number
  status: 'active' | 'archived'
}

export interface StudentAccount {
  id: string
  username: string
  nickname: string
  grade: string
  status: 'active' | 'paused'
  createdAt: string
  spaces: number
}

export interface RuleConfig {
  dailyProactiveActionLimit: number // 每日主动动作上限
  conceptProactiveReminderLimit: number // 单知识点主动提醒上限
  quietHoursStart: string // 静默时段开始
  quietHoursEnd: string // 静默时段结束
  reviewIntervals: number[] // 间隔复习天数
  migrationVariantCount: number // SHORT→STABLE 需通过的高价值迁移题数
  stopAfterStable: boolean // 稳定掌握后是否停止该知识点
}

export interface AttentionState {
  todayProactiveActions: number
  todayReminders: number
  todayFocusMinutes: number
  todayCompleted: boolean // 今日是否已结束（停止语义）
}

export const DEMO_NOTE = '演示数据 · 算法见《系统设计.md》'

/* ---------------- 知识点（六年级上 · 人教） ---------------- */
export const seedKps: KnowledgePoint[] = [
  {
    id: 'kp_frac_mean',
    name: '分数意义',
    domain: '数与运算',
    important: false,
    state: 'stable',
    estimate: 96,
    confidence: 0.93,
    stability: 0.95,
    prerequisites: [],
  },
  {
    id: 'kp_frac_mul_int',
    name: '分数乘整数',
    domain: '数与运算',
    important: true,
    state: 'stable',
    estimate: 92,
    confidence: 0.9,
    stability: 0.91,
    prerequisites: ['kp_frac_mean'],
  },
  {
    id: 'kp_frac_mul',
    name: '分数乘分数',
    domain: '数与运算',
    important: true,
    state: 'learning',
    estimate: 62,
    confidence: 0.58,
    stability: 0.4,
    prerequisites: ['kp_frac_mul_int'],
  },
  {
    id: 'kp_frac_of_num',
    name: '求一个数的几分之几',
    domain: '数与运算',
    important: true,
    state: 'untouched',
    estimate: 0,
    confidence: 0,
    stability: 0,
    prerequisites: ['kp_frac_mul'],
  },
  {
    id: 'kp_simplify',
    name: '分数乘法·约分与运算律',
    domain: '数与运算',
    important: false,
    state: 'learning',
    estimate: 48,
    confidence: 0.5,
    stability: 0.35,
    prerequisites: ['kp_frac_mul'],
  },
  {
    id: 'kp_frac_app',
    name: '分数乘法应用题',
    domain: '解决问题',
    important: true,
    state: 'untouched',
    estimate: 0,
    confidence: 0,
    stability: 0,
    prerequisites: ['kp_frac_of_num'],
  },
  {
    id: 'kp_reciprocal',
    name: '倒数',
    domain: '数与运算',
    important: false,
    state: 'untouched',
    estimate: 0,
    confidence: 0,
    stability: 0,
    prerequisites: ['kp_frac_mul'],
  },
]

/* ---------------- 证据账本（本周已发生的过往事件） ---------------- */
export const seedEvidence: EvidenceRecord[] = [
  {
    id: 'e-101',
    time: '周一 17:05',
    kpId: 'kp_frac_mul_int',
    kpName: '分数乘整数',
    type: 'practice',
    result: 'pass',
    weight: 0.6,
    source: '人教六上 P2 例题后练习',
    note: '3/4 × 8 等 3 道全对',
  },
  {
    id: 'e-102',
    time: '周一 17:12',
    kpId: 'kp_frac_mul_int',
    kpName: '分数乘整数',
    type: 'variant',
    result: 'pass',
    weight: 0.8,
    source: '变式题 · 即时迁移',
    note: '换个情境仍会做，思路一句话正确',
  },
  {
    id: 'e-103',
    time: '周一 17:15',
    kpId: 'kp_frac_mul_int',
    kpName: '分数乘整数',
    type: 'review',
    result: 'pass',
    weight: 0.5,
    source: '间隔复习 · 第 1 天',
    note: '复习通过，进入第 3 天间隔',
  },
  {
    id: 'e-201',
    time: '周二 17:02',
    kpId: 'kp_frac_mul',
    kpName: '分数乘分数',
    type: 'quiz',
    result: 'fail',
    weight: 0.4,
    source: '课后检验 2/5 × 5/6',
    note: '归因：粗心（最后一步约分错）',
  },
  {
    id: 'e-202',
    time: '今天 17:02',
    kpId: 'kp_frac_mul',
    kpName: '分数乘分数',
    type: 'practice',
    result: 'pass',
    weight: 0.6,
    source: '讲解后基础练习 3 道',
    note: '归因后重新练习，全对',
  },
  {
    id: 'e-301',
    time: '周三 17:20',
    kpId: 'kp_simplify',
    kpName: '分数乘法·约分与运算律',
    type: 'quiz',
    result: 'fail',
    weight: 0.4,
    source: '课堂小测',
    note: '归因：概念不清（运算律混淆）',
  },
]

/* ---------------- 决策记录（政策引擎，本周） ---------------- */
export const seedDecisions: PolicyDecision[] = [
  {
    id: 'd-101',
    time: '周一 17:15',
    kpId: 'kp_frac_mul_int',
    kpName: '分数乘整数',
    trigger: '基础练习全对 + 变式(即时迁移)通过 + 复习第1天通过',
    action: '判定稳定掌握 → 停止该知识点主动练习',
    reason: '三条独立证据一致通过，估计器达到 STABLE 阈值（演示阈值 0.8）。',
    fromState: 'short',
    toState: 'stable',
  },
  {
    id: 'd-201',
    time: '今天 17:05',
    kpId: 'kp_frac_mul',
    kpName: '分数乘分数',
    trigger: '归因(粗心) + 讲解后基础练习全对',
    action: '状态保持【学习中】→ 安排变式验收',
    reason: '单次全对不直接切换状态；待变式（即时迁移）证据后再判定。',
    fromState: 'learning',
    toState: 'learning',
  },
]

/* ---------------- 学习空间 / 学生账号 ---------------- */
export const seedSpaces: LearningSpace[] = [
  {
    id: 'sp_school',
    name: '学校 · 六年级上册数学',
    studentName: '小鹿同学',
    textbook: '人教版 六上（1-4 单元）',
    progress: '第一单元 分数乘法 · 第 2 节',
    boundKp: 7,
    trackedKp: 4,
    status: 'active',
  },
  {
    id: 'sp_tutor',
    name: '辅导班 · 思维拓展',
    studentName: '小鹿同学',
    textbook: '自编专题（分数与比）',
    progress: '专题 2 · 分数应用',
    boundKp: 5,
    trackedKp: 2,
    status: 'active',
  },
]

export const seedStudents: StudentAccount[] = [
  {
    id: 's_1',
    username: 'xiaolu_0608',
    nickname: '小鹿同学',
    grade: '六年级',
    status: 'active',
    createdAt: '2026-08-01',
    spaces: 2,
  },
]

/* ---------------- 规则配置（Attention Budget MVP 默认值 §8.3） ---------------- */
export const seedRules: RuleConfig = {
  dailyProactiveActionLimit: 3,
  conceptProactiveReminderLimit: 1,
  quietHoursStart: '21:00',
  quietHoursEnd: '07:00',
  reviewIntervals: [1, 3, 7],
  migrationVariantCount: 1,
  stopAfterStable: true,
}

export const seedAttention: AttentionState = {
  todayProactiveActions: 1,
  todayReminders: 0,
  todayFocusMinutes: 20,
  todayCompleted: false,
}
