import { createRouter, createWebHashHistory } from 'vue-router'
import ChildShell from '@/components/ChildShell.vue'
import ParentShell from '@/components/ParentShell.vue'

import HomeView from '@/views/child/HomeView.vue'
import MogiView from '@/views/child/MogiView.vue'
import PhotoView from '@/views/child/PhotoView.vue'
import AttributionView from '@/views/child/AttributionView.vue'
import ReadingView from '@/views/child/ReadingView.vue'
import ExplainView from '@/views/child/ExplainView.vue'
import PracticeView from '@/views/child/PracticeView.vue'
import VariantView from '@/views/child/VariantView.vue'
import SummaryView from '@/views/child/SummaryView.vue'
import ReviewView from '@/views/child/ReviewView.vue'
import ProgressView from '@/views/child/ProgressView.vue'
import ProfileView from '@/views/child/ProfileView.vue'

import ParentTodayView from '@/views/parent/ParentTodayView.vue'
import ParentWeeklyView from '@/views/parent/ParentWeeklyView.vue'
import ParentAccountsView from '@/views/parent/ParentAccountsView.vue'
import ParentSpacesView from '@/views/parent/ParentSpacesView.vue'

import AdminShell from '@/components/AdminShell.vue'
import AdminDashboardView from '@/views/admin/AdminDashboardView.vue'
import AdminKnowledgeView from '@/views/admin/AdminKnowledgeView.vue'
import AdminDecisionsView from '@/views/admin/AdminDecisionsView.vue'
import AdminRulesView from '@/views/admin/AdminRulesView.vue'

import StudentLoginView from '@/views/student/StudentLoginView.vue'
import StudentHomeView from '@/views/student/StudentHomeView.vue'
import StudentPhotoView from '@/views/student/StudentPhotoView.vue'
import StudentConfirmView from '@/views/student/StudentConfirmView.vue'
import StudentExplainView from '@/views/student/StudentExplainView.vue'
import StudentReadingView from '@/views/student/StudentReadingView.vue'
import StudentTeachBackView from '@/views/student/StudentTeachBackView.vue'
import StudentSettingsView from '@/views/student/StudentSettingsView.vue'

const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/', redirect: '/student/home' },
    {
      path: '/student',
      children: [
        { path: '', redirect: '/student/home' },
        { path: 'login', component: StudentLoginView },
        { path: 'home', component: StudentHomeView },
        { path: 'photo', component: StudentPhotoView },
        { path: 'confirm', component: StudentConfirmView },
        { path: 'explain', component: StudentExplainView },
        { path: 'reading', component: StudentReadingView },
        { path: 'teachback', component: StudentTeachBackView },
        { path: 'settings', component: StudentSettingsView },
      ],
    },
    {
      path: '/child',
      component: ChildShell,
      children: [
        { path: '', redirect: '/child/home' },
        { path: 'home', component: HomeView },
        { path: 'mogi', component: MogiView },
        { path: 'photo', component: PhotoView },
        { path: 'attribution', component: AttributionView },
        { path: 'reading', component: ReadingView },
        { path: 'explain', component: ExplainView },
        { path: 'practice', component: PracticeView },
        { path: 'variant', component: VariantView },
        { path: 'summary', component: SummaryView },
        { path: 'review', component: ReviewView },
        { path: 'progress', component: ProgressView },
        { path: 'profile', component: ProfileView },
      ],
    },
    {
      path: '/parent',
      component: ParentShell,
      children: [
        { path: '', redirect: '/parent/today' },
        { path: 'today', component: ParentTodayView },
        { path: 'weekly', component: ParentWeeklyView },
        { path: 'students', component: ParentAccountsView },
        { path: 'spaces', component: ParentSpacesView },
      ],
    },
    {
      path: '/admin',
      component: AdminShell,
      children: [
        { path: '', component: AdminDashboardView },
        { path: 'knowledge', component: AdminKnowledgeView },
        { path: 'decisions', component: AdminDecisionsView },
        { path: 'rules', component: AdminRulesView },
      ],
    },
  ],
})

export default router
