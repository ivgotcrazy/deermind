<script setup lang="ts">
import { computed, ref } from 'vue'
import { useEvidenceStore } from '@/stores/evidence'
import { DEMO_NOTE, EVIDENCE_TYPE_LABEL } from '@/data/sharedMock'
import type { KnowledgePoint } from '@/data/sharedMock'
import StateBadge from '@/components/admin/StateBadge.vue'

const ev = useEvidenceStore()
const selectedId = ref(ev.kps[0]?.id ?? '')

const selected = computed<KnowledgePoint | undefined>(() => ev.findKp(selectedId.value))
const prereqNames = computed(() =>
  (selected.value?.prerequisites ?? [])
    .map((p) => ev.findKp(p)?.name ?? p)
    .join('、'),
)
const kpEvidence = computed(() =>
  ev.evidence.filter((e) => e.kpId === selectedId.value).slice(-10).reverse(),
)
const kpDecisions = computed(() =>
  ev.decisions.filter((d) => d.kpId === selectedId.value).slice(-4).reverse(),
)
</script>

<template>
  <div class="kpage">
    <div class="page-head">
      <h1>知识点详情</h1>
      <p class="desc">掌握度可追溯：证据 → 估计器（演示）→ 决策理由（{{ DEMO_NOTE }}）</p>
    </div>

    <div class="grid">
      <!-- 知识点列表 -->
      <section class="panel">
        <div class="panel-title">知识点（{{ ev.kps.length }}）</div>
        <table class="tbl">
          <thead>
            <tr>
              <th>名称</th>
              <th>状态</th>
              <th class="num">估计</th>
              <th class="num">置信</th>
              <th class="num">稳定</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="k in ev.kps"
              :key="k.id"
              :class="{ on: selectedId === k.id }"
              @click="selectedId = k.id"
            >
              <td class="kp-name">{{ k.name }}</td>
              <td><StateBadge :state="k.state" /></td>
              <td class="num">{{ k.estimate }}</td>
              <td class="num">{{ (k.confidence * 100).toFixed(0) }}%</td>
              <td class="num">{{ (k.stability * 100).toFixed(0) }}%</td>
            </tr>
          </tbody>
        </table>
      </section>

      <!-- 详情面板 -->
      <section v-if="selected" class="panel detail">
        <div class="d-head">
          <span class="d-name">{{ selected.name }}</span>
          <StateBadge :state="selected.state" />
        </div>
        <div class="d-meta">
          领域：{{ selected.domain }} · {{ selected.important ? '重要' : '一般' }} · 前置：{{ prereqNames || '无' }}
        </div>
        <div class="d-nums">
          <div class="d-num"><span class="l">估计掌握</span><span class="v">{{ selected.estimate }}</span></div>
          <div class="d-num"><span class="l">置信度</span><span class="v">{{ (selected.confidence * 100).toFixed(0) }}%</span></div>
          <div class="d-num"><span class="l">稳定度</span><span class="v">{{ (selected.stability * 100).toFixed(0) }}%</span></div>
        </div>

        <div class="sec">证据时间线（{{ kpEvidence.length }}）</div>
        <ul class="tl">
          <li v-for="e in kpEvidence" :key="e.id" class="tl-item">
            <span class="t">{{ e.time }}</span>
            <div class="tl-body">
              <span class="etype" :class="e.result">{{ EVIDENCE_TYPE_LABEL[e.type] }} · {{ e.result === 'pass' ? '通过' : '未通过' }}</span>
              <span class="w">权重 {{ e.weight.toFixed(2) }}</span>
              <div class="note">{{ e.note }}（{{ e.source }}）</div>
            </div>
          </li>
          <li v-if="!kpEvidence.length" class="muted">暂无证据</li>
        </ul>

        <div class="sec">决策理由（可解释性）</div>
        <ul class="tl">
          <li v-for="d in kpDecisions" :key="d.id" class="tl-item">
            <span class="t">{{ d.time }}</span>
            <div class="tl-body">
              <div class="dr-action">{{ d.action }}</div>
              <div class="dr-reason">{{ d.reason }}</div>
            </div>
          </li>
          <li v-if="!kpDecisions.length" class="muted">暂无决策</li>
        </ul>
      </section>
    </div>
  </div>
</template>

<style scoped>
.kpage {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.page-head h1 {
  margin: 0;
  font-size: 20px;
}
.page-head .desc {
  margin: 4px 0 0;
  font-size: 12.5px;
  color: #64748b;
}
.grid {
  display: grid;
  grid-template-columns: minmax(360px, 0.9fr) 1.1fr;
  gap: 12px;
  align-items: start;
}
@media (max-width: 900px) {
  .grid {
    grid-template-columns: 1fr;
  }
}
.panel {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 14px 16px;
}
.panel-title {
  font-size: 13px;
  font-weight: 700;
  color: #334155;
  margin-bottom: 10px;
}
.tbl {
  width: 100%;
  border-collapse: collapse;
}
.tbl th {
  font-size: 12px;
  font-weight: 600;
  color: #64748b;
  text-align: left;
  padding: 6px 8px;
  border-bottom: 1px solid #e2e8f0;
}
.tbl th.num,
.tbl td.num {
  text-align: right;
}
.tbl td {
  font-size: 13px;
  padding: 8px;
  border-bottom: 1px solid #f1f5f9;
  cursor: pointer;
  font-variant-numeric: tabular-nums;
}
.tbl tr:hover td {
  background: #f8fafc;
}
.tbl tr.on td {
  background: #eef2ff;
}
.kp-name {
  font-weight: 600;
}
.detail {
  position: sticky;
  top: 0;
}
.d-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.d-name {
  font-size: 17px;
  font-weight: 800;
}
.d-meta {
  font-size: 12.5px;
  color: #64748b;
  margin-top: 4px;
}
.d-nums {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
  margin: 12px 0;
}
.d-num {
  background: #f8fafc;
  border-radius: 8px;
  padding: 10px;
  text-align: center;
}
.d-num .l {
  display: block;
  font-size: 11px;
  color: #64748b;
}
.d-num .v {
  font-size: 20px;
  font-weight: 800;
  font-variant-numeric: tabular-nums;
}
.sec {
  font-size: 13px;
  font-weight: 700;
  color: #334155;
  margin: 12px 0 8px;
}
.tl {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.tl-item {
  display: flex;
  gap: 10px;
}
.tl-item .t {
  font-size: 12px;
  font-weight: 700;
  color: var(--color-primary);
  flex-shrink: 0;
  padding-top: 2px;
}
.tl-body {
  flex: 1;
  border-left: 2px solid #eef2ff;
  padding-left: 10px;
}
.etype {
  font-size: 11px;
  font-weight: 700;
  padding: 1px 8px;
  border-radius: 999px;
}
.etype.pass {
  background: #dcfce7;
  color: #15803d;
}
.etype.fail {
  background: #fee2e2;
  color: #b91c1c;
}
.w {
  font-size: 11px;
  color: #94a3b8;
  margin-left: 6px;
}
.note {
  font-size: 12.5px;
  color: #475569;
  margin-top: 2px;
}
.dr-action {
  font-size: 13px;
  font-weight: 600;
}
.dr-reason {
  font-size: 12px;
  color: #64748b;
  margin-top: 2px;
}
.muted {
  font-size: 12.5px;
  color: #94a3b8;
}
</style>
