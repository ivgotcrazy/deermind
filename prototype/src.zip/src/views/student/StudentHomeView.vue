<script setup lang="ts">
import { nextTick, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useStudentChat } from '@/stores/studentChat'
import { studentInfo } from '@/data/studentMock'
import DeerAvatar from '@/components/DeerAvatar.vue'
import Icon from '@/components/Icon.vue'
import ChatMessage from '@/components/student/ChatMessage.vue'

const store = useStudentChat()
const router = useRouter()

const draft = ref('')
const voice = ref(false)
const listRef = ref<HTMLElement>()

function scrollBottom() {
  nextTick(() => {
    if (listRef.value) listRef.value.scrollTop = listRef.value.scrollHeight
  })
}
watch(() => store.messages.length, scrollBottom)
watch(() => store.typing, scrollBottom)

onMounted(() => {
  if (!store.loggedIn) {
    router.replace('/student/login')
    return
  }
  scrollBottom()
})

function send() {
  const nav = store.send(draft.value)
  draft.value = ''
  if (nav) router.push(nav)
}

function onQuick(kind: 'quiz' | 'review' | 'variant') {
  store.quick(kind)
}

function logout() {
  store.logout()
  router.push('/student/login')
}
</script>

<template>
  <div class="home">
    <!-- 顶部 -->
    <header class="top">
      <div class="avatar"><DeerAvatar :size="40" /></div>
      <div class="info">
        <div class="name">{{ studentInfo.spaceName }}</div>
        <div class="prog">{{ studentInfo.spaceProgress }}</div>
      </div>
      <span class="streak">🔥 {{ studentInfo.streakDays }} 天</span>
      <button class="icon-btn" title="设置" @click="router.push('/student/settings')">
        <Icon name="settings" :size="20" />
      </button>
      <button class="ghost small" @click="logout">登出</button>
    </header>

    <!-- 今日任务卡（从共享掌握度状态派生） -->
    <section class="plan-card">
      <div class="plan-title">📋 今日任务（最省时方案）</div>
      <div class="plan-body">
        <template v-if="store.plan.review.length">
          <div class="plan-row">
            <span class="tag tag-review">待复习</span>
            <span class="kp">{{ store.plan.review[0].kp }}</span>
            <span class="note">{{ store.plan.review[0].day }}</span>
          </div>
        </template>
        <template v-if="store.plan.migration.length">
          <div class="plan-row">
            <span class="tag tag-migration">待迁移</span>
            <span class="kp">{{ store.plan.migration[0].kp }}</span>
            <span class="note">迁移题 · 验证稳定性</span>
          </div>
        </template>
        <template v-if="store.plan.learn.length">
          <div class="plan-row">
            <span class="tag tag-learn">待学</span>
            <span class="kp">{{ store.plan.learn[0].kp }}</span>
            <span class="note">{{ store.plan.learn[0].note }}</span>
          </div>
        </template>
        <template v-if="store.plan.mastered.length">
          <div class="plan-row done">
            <span class="tag tag-mastered">已掌握</span>
            <span class="kp">{{ store.plan.mastered.slice(0, 2).join('、') }}</span>
            <span class="note">今天不用学</span>
          </div>
        </template>
        <div v-if="!store.plan.review.length && !store.plan.migration.length && !store.plan.learn.length" class="plan-empty">
          今天没有需要你继续处理的数学问题，可以去玩啦 🎉
        </div>
      </div>
    </section>

    <!-- 大对话区 -->
    <main ref="listRef" class="chat">
      <ChatMessage v-for="m in store.messages" :key="m.id" :msg="m" />
      <div v-if="store.typing" class="typing"><span></span><span></span><span></span></div>
    </main>

    <!-- 输入区 -->
    <footer class="input">
      <div class="quick">
        <button class="q" @click="router.push('/student/photo')"><Icon name="camera" :size="16" /> 拍错题</button>
        <button class="q" @click="onQuick('quiz')"><Icon name="sparkles" :size="16" /> 考考我</button>
        <button class="q" @click="onQuick('review')"><Icon name="refresh" :size="16" /> 复习</button>
        <button class="q" @click="onQuick('variant')"><Icon name="check" :size="16" /> 迁移题</button>
        <button class="q" @click="router.push('/student/teachback')"><Icon name="speaker" :size="16" /> 讲给小鹿</button>
        <button class="q" @click="router.push('/student/reading')"><Icon name="doc" :size="16" /> 读题</button>
      </div>
      <div class="bar">
        <button class="mic" :class="{ on: voice }" title="语音输入" @click="voice = !voice">
          <Icon :name="voice ? 'volumeOff' : 'speaker'" :size="20" />
        </button>
        <input
          v-model="draft"
          class="text"
          placeholder="跟小鹿说说话，或按语音…"
          @keyup.enter="send"
        />
        <button class="send" :disabled="!draft.trim()" @click="send">
          <Icon name="play" :size="18" />
        </button>
      </div>
      <div v-if="voice" class="voice-tip">🎤 请说话…（原型演示：模拟语音输入）</div>
    </footer>
  </div>
</template>

<style scoped>
.home {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: var(--color-background);
  max-width: 760px;
  margin: 0 auto;
  width: 100%;
}
.top {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px 8px;
}
.info {
  flex: 1;
  min-width: 0;
}
.name {
  font-family: var(--font-head);
  font-weight: 700;
  font-size: 15px;
  line-height: 1.2;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.prog {
  font-size: 12px;
  opacity: 0.7;
  margin-top: 2px;
}
.streak {
  font-size: 13px;
  font-weight: 700;
  color: var(--color-warning);
  background: var(--color-warning-soft);
  padding: 4px 10px;
  border-radius: 999px;
  white-space: nowrap;
}
.icon-btn {
  border: 0;
  background: transparent;
  cursor: pointer;
  color: var(--color-text);
  opacity: 0.8;
}
.ghost.small {
  border: 0;
  background: var(--color-primary-soft);
  color: var(--color-primary);
  font-weight: 700;
  font-size: 12.5px;
  padding: 6px 12px;
  border-radius: 12px;
  cursor: pointer;
}
.plan-card {
  margin: 4px 16px 8px;
  background: var(--color-white);
  border-radius: var(--radius-card);
  box-shadow: var(--shadow-clay);
  padding: 12px 14px;
}
.plan-title {
  font-family: var(--font-head);
  font-weight: 700;
  font-size: 14px;
  color: var(--color-text);
  margin-bottom: 8px;
}
.plan-body {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.plan-row {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13.5px;
  padding: 7px 10px;
  border-radius: 12px;
  background: var(--color-primary-soft);
}
.plan-row.done {
  background: var(--color-cta-soft);
}
.tag {
  font-size: 11px;
  font-weight: 700;
  padding: 2px 8px;
  border-radius: 999px;
}
.tag-review {
  background: var(--color-warning-soft);
  color: var(--color-warning);
}
.tag-learn {
  background: var(--color-secondary-soft);
  color: var(--color-primary);
}
.tag-mastered {
  background: var(--color-cta-soft);
  color: var(--color-cta);
}
.tag-migration {
  background: var(--color-secondary-soft);
  color: var(--color-primary);
}
.plan-empty {
  font-size: 14px;
  font-weight: 700;
  color: var(--color-cta);
  padding: 4px 0;
}
.kp {
  font-weight: 700;
}
.note {
  margin-left: auto;
  font-size: 12px;
  opacity: 0.7;
}
.chat {
  flex: 1;
  overflow-y: auto;
  padding: 8px 16px 12px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.typing {
  display: flex;
  gap: 5px;
  padding: 10px 14px;
  background: var(--color-white);
  border-radius: 18px;
  width: fit-content;
  box-shadow: var(--shadow-clay);
}
.typing span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--color-secondary);
  animation: blink 1.2s infinite;
}
.typing span:nth-child(2) {
  animation-delay: 0.2s;
}
.typing span:nth-child(3) {
  animation-delay: 0.4s;
}
@keyframes blink {
  0%,
  80%,
  100% {
    opacity: 0.3;
  }
  40% {
    opacity: 1;
  }
}
.input {
  padding: 8px 16px 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  border-top: 1px solid var(--color-line);
  background: rgba(255, 255, 255, 0.6);
}
.quick {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
.q {
  border: 0;
  cursor: pointer;
  font-family: var(--font-body);
  font-size: 13px;
  font-weight: 700;
  padding: 7px 12px;
  border-radius: 999px;
  background: var(--color-primary-soft);
  color: var(--color-primary);
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.bar {
  display: flex;
  align-items: center;
  gap: 8px;
}
.mic,
.send {
  border: 0;
  cursor: pointer;
  width: 42px;
  height: 42px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex: 0 0 auto;
}
.mic {
  background: var(--color-secondary-soft);
  color: var(--color-primary);
}
.mic.on {
  background: var(--color-cta);
  color: #fff;
}
.send {
  background: var(--color-cta);
  color: #fff;
}
.send:disabled {
  opacity: 0.4;
  cursor: default;
}
.text {
  flex: 1;
  height: 42px;
  border: 2px solid var(--color-line);
  border-radius: 21px;
  padding: 0 16px;
  font-family: var(--font-body);
  font-size: 15px;
}
.text:focus {
  outline: none;
  border-color: var(--color-secondary);
}
.voice-tip {
  text-align: center;
  font-size: 13px;
  color: var(--color-primary);
}
</style>
