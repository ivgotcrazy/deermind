<script setup lang="ts">
import { computed } from 'vue'
import { useEvidenceStore } from '@/stores/evidence'
import { EVIDENCE_TYPE_LABEL, DEMO_NOTE } from '@/data/sharedMock'
import Icon from '@/components/Icon.vue'

const ev = useEvidenceStore()

const todayEvidence = computed(() => ev.evidence.slice(-6).reverse())

const stats = computed(() => [
  { label: '今日专注', value: `${ev.attention.todayFocusMinutes} 分`, icon: 'chart' },
  {
    label: '主动动作',
    value: `${ev.attention.todayProactiveActions}/${ev.rules.dailyProactiveActionLimit} 次`,
    icon: 'check',
  },
  { label: '今日状态', value: ev.attention.todayCompleted ? '已收工 ✓' : '进行中', icon: 'calendar' },
])

const attentionWarning = computed(
  () => ev.attention.todayProactiveActions >= ev.rules.dailyProactiveActionLimit,
)

const weakness = computed(() =>
  ev.kps.filter((k) => k.state === 'learning').map((k) => ({ name: k.name, estimate: k.estimate })),
)
</script>

<template>
  <div class="today">
    <h2 class="title">今日学习 · 8 月 23 日 <span class="demo">{{ DEMO_NOTE }}</span></h2>

    <div class="stats">
      <div v-for="s in stats" :key="s.label" class="stat">
        <Icon :name="s.icon" :size="20" />
        <span class="v">{{ s.value }}</span>
        <span class="l">{{ s.label }}</span>
      </div>
    </div>

    <section class="card">
      <div class="sec-title">学习记录（证据账本）</div>
      <ul class="records">
        <li v-for="r in todayEvidence" :key="r.id" class="rec">
          <span class="t">{{ r.time }}</span>
          <span class="tag" :class="r.result === 'pass' ? 'pass' : 'fail'">
            {{ EVIDENCE_TYPE_LABEL[r.type] }} · {{ r.result === 'pass' ? '通过' : '未通过' }}
          </span>
          <div class="txt">{{ r.kpName }}：{{ r.note }}</div>
        </li>
      </ul>
    </section>

    <section v-if="attentionWarning" class="card warn">
      <div class="head">
        <Icon name="sparkles" :size="18" />
        <span>Attention Budget 提醒</span>
      </div>
      <p>今日主动动作已达上限（{{ ev.rules.dailyProactiveActionLimit }} 次），之后由孩子主动发起，AI 不再主动打扰。</p>
    </section>

    <section v-else class="card alert">
      <div class="head">
        <Icon name="sparkles" :size="18" />
        <span>今日小结</span>
      </div>
      <template v-if="ev.attention.todayCompleted">
        <p>孩子今天已完成全部计划任务并收工，剩余时间自由支配 🎉</p>
      </template>
      <template v-else>
        <p v-if="weakness.length">
          待巩固知识点：<b v-for="w in weakness" :key="w.name" class="chip">{{ w.name }}</b>
        </p>
        <p class="sugg">建议：继续「分数乘分数」的迁移题验证稳定性（约 8 分钟）</p>
      </template>
    </section>
  </div>
</template>

<style scoped>
.today {
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.title {
  margin: 0;
  font-size: 19px;
  display: flex;
  align-items: baseline;
  gap: 8px;
  flex-wrap: wrap;
}
.demo {
  font-size: 11px;
  font-weight: 600;
  color: #b45309;
  background: var(--color-warning-soft);
  padding: 2px 8px;
  border-radius: 999px;
}
.stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}
.stat {
  background: #fff;
  border-radius: 14px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  color: var(--color-primary);
  box-shadow: var(--shadow-clay);
}
.stat .v {
  font-size: 16px;
  font-weight: 800;
  color: var(--color-text);
}
.stat .l {
  font-size: 11px;
  opacity: 0.7;
}
.sec-title {
  font-weight: 800;
  margin-bottom: 10px;
}
.records {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.rec {
  display: flex;
  align-items: baseline;
  gap: 8px;
  flex-wrap: wrap;
  font-size: 13px;
}
.rec .t {
  color: var(--color-primary);
  font-weight: 700;
  font-size: 12px;
}
.rec .txt {
  width: 100%;
  padding-left: 56px;
  opacity: 0.85;
}
.tag {
  font-size: 11px;
  font-weight: 700;
  padding: 2px 8px;
  border-radius: 999px;
}
.tag.pass {
  background: var(--color-cta-soft);
  color: #15803d;
}
.tag.fail {
  background: var(--color-danger-soft);
  color: #b91c1c;
}
.alert,
.warn {
  border-top: 4px solid var(--color-warning);
}
.warn {
  border-top-color: var(--color-warning);
}
.head {
  display: flex;
  align-items: center;
  gap: 6px;
  font-weight: 800;
  color: #b45309;
  margin-bottom: 6px;
}
.alert p,
.warn p {
  margin: 0 0 6px;
  font-size: 13px;
  line-height: 1.6;
}
.chip {
  display: inline-block;
  margin: 0 4px;
  font-style: normal;
}
.sugg {
  color: var(--color-primary);
}
</style>
