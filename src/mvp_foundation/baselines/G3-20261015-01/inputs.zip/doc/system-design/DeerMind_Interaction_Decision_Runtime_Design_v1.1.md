# DeerMind Interaction & Decision Runtime Design v1.1

> **中文名称**：DeerMind 交互与决策运行时设计<br>
> **版本**：v1.1<br>
> **文档性质**：System Design Baseline<br>
> **状态**：领域模型修订后的实现合同；本轮未新增运行验证或 Gate 结论<br>
> **上位基线**：[Concept Architecture v1.2](../concept-design/DeerMind_Concept_Architecture_v1.2.md)、[Domain Space v1.0](../concept-design/DeerMind_Domain_Space_Design_v1.0.md)、[Learning Space v1.0](../concept-design/DeerMind_Learning_Space_Design_v1.0.md)、Evaluation / Interaction / Evolution v1.2、[AI-Native Principles v0.3](../top/DeerMind_AI_Native_Architecture_Principles_v0.3.md)；总体合同为 [System Design v1.1](DeerMind_System_Design_v1.1.md)<br>
> **阶段路线图**：`DeerMind_System_Design_Roadmap_v0.6.md`<br>
> **写作规范**：`DeerMind_Design_Document_Standard_v1.0.md`<br>
> **更新时间**：2026-10-11

本版本在原 System Design v1.0 合同上承接 Domain 与 Learning Space 的对象和 owner 修订。事实、认知、权限、严格会话串行和 typed invalidation 机制保持；本轮调整规范输入、版本依赖与变更路由，不声称旧实现已经迁移。[历史证据评审](DeerMind_System_Design_Evidence_Review_v1.0.md)、[Spike 报告](spike/DeerMind_Architecture_Validation_Report_v0.1.md)与 [Build 报告](build/DeerMind_Architecture_Validation_Build_Validation_Report_v0.3.md)继续按各自原始版本解释，原失败及未决结论不变。
---

## 1. 文档定位与设计命题

### 1.1 为什么需要独立 Interaction & Decision Runtime Design

DeerMind 的 Interaction Space 解决的是最接近现实的一层问题：当前发生了什么、什么仍然有效、系统此刻是否值得行动、如果行动应该做什么，以及这个行动是否真的发生。

上位 Space Design 已经明确 Interaction 的语义责任，但从语义模型走向运行系统还存在一组不能留给实现阶段临时决定的问题：

- 一个 Observation 或 Belief 变化是否自动触发行动；
- 当前 Target、Binding、Obligation、Goal、Authority 与 Plan 如何进入同一次 Decision；
- 哪些 Action 当前“合法”，哪些只是“值得做”；
- `NoIntervention` 和 `Defer` 如何成为真实、可审计的运行结果；
- AI Policy 判断完成后怎样形成受控的 `ActionIntent`；
- 新 Event 在 reasoning 期间到达时，旧 Decision 是否还允许提交；
- `ActionIntent` 提交以后是否还需要因为每个新 Event 重跑 Policy；
- Assistance 的信息暴露如何沿真实 Action occurrence 被记录，而不是依据“系统原本打算给什么”；
- Plan 如何跨时间存在而又不退化成未来命令队列；
- Runtime Learner Condition 如何影响当前决策而不成为长期 Learner Belief；
- Authority、Safety、External Obligation 如何限制行动空间而不直接取得教学决策权。

如果这些问题没有明确运行合同，Interaction 很容易退化为传统 Agent 的“拿到上下文 → 决定下一步 → 执行工具”模式。那样会重新混合事实、认识、策略与执行权，并破坏 DeerMind 已冻结的 semantic ownership。

因此本专项的核心设计命题是：

\[
\boxed{
InteractionDecisionRuntime
=
CurrentContext
+
ConstrainedPolicyJudgment
+
ControlledActionExecution
}
\]

并且：

\[
\boxed{
DecisionTrigger
\neq
InterventionMandate
}
\]

\[
\boxed{
Admissible
\neq
WorthDoing
}
\]

\[
\boxed{
ActionCandidate
\neq
ActionIntent
\neq
ActionOccurrence
}
\]

Interaction Runtime 的职责不是“让 AI 尽可能多地参与”，而是保证 DeerMind **只在当前上下文一致、权限成立、行动值得、干预充分且必要时才产生现实 effect；否则能够正式地不行动或等待。**

### 1.2 本文档解决什么

本文档负责定义：

- Decision Opportunity、Decision Trigger、Decision Cycle 的身份与边界；
- purpose-bound Decision Context 的组成、解析、快照与 currentness；
- Goal Intent、Learning Target、Target Assessment、Target Gap、Epistemic Gap、Target Binding、External Obligation、Context Authority 与 Plan 的运行分层；
- pre-reasoning admissible action envelope 与 Policy reasoning 的边界；
- Interaction Policy 的 Protocol、输入、候选生成、value / cost assessment、minimum sufficient selection 与 rationale；
- `Execute(ActionCandidate) / NoIntervention / Defer` 的正式运行语义；
- Action semantics、ActionCandidate、ActionIntent、Executor 与 ActionOccurrence 的责任链；
- ActionIntent 的 expiry、precondition、idempotency 与 effect-time recheck；
- Runtime Learner Condition 的短期生命周期；
- Multi-timescale Plan、expiration、stale、abandon 与 replanning；
- Assistance Exposure Lineage 与 Information Disclosure / Cognitive Work Substitution；
- Task Canonical Tool Semantics、Target Support Boundary、Runtime Tool Availability 与 Occurred Tool Use 四层工具语义；
- Active Assessment 的运行 ownership；
- concurrent event / belief / authority change 导致 stale 时的 re-decision；
- Policy failure、execution failure、NoCurrentValidState、NotOccurred、Indeterminate 等 non-happy path；
- Interaction 的 provenance、audit、replay 与相邻 Work Package contract；
- 与 Consolidated Architecture Spike Dimension D / E 相关的 Pre-Validation assumptions。

### 1.3 本文档不解决什么

本文档不冻结：

- Interaction Policy 必须使用某个具体 LLM、规则引擎、规划器或强化学习算法；
- Policy 的 prompt 模板、temperature、token budget；
- UI 如何呈现 Hint、Explain、Question、Task、Stop 等产品动作；
- Action transport 使用 HTTP、WebSocket、push、RPC 或其他协议；
- Plan 的具体数据库 schema；
- Decision Context 的最终 JSON / protobuf 字段；
- Executor 的服务拆分与部署拓扑；
- Tool backend 的具体供应商与 IAM 产品；
- latency SLO、retry 次数、队列产品、生产级容量；
- 首个 Product Context 的完整教学策略库。

这些实现选择可以演进，但不得破坏本文档冻结的 decision / authority / action / exposure contracts。

### 1.4 与总体 System Design 和 Interaction Space 的关系

`Interaction Space Design v1.2` 定义 Interaction 的稳定语义责任；总体 `DeerMind_System_Design_v1.1` 把 Interaction 放入全系统 MVCL、Current Resolution、AI Runtime、State / Dependency、Event History 和 Evaluation 闭环中；本文档把其中的 Decision 与 Action 部分深化到 Focused Design Closure。

```text
Interaction Space
    定义 Observation / State / Action / Policy 的语义责任
        ↓
Integrated System Design
    定义 Interaction 在全系统闭环中的位置
        ↓
Interaction & Decision Runtime
    定义 current context 如何形成 decision，
    decision 如何取得正式 standing，
    以及 action 如何成为现实 occurrence
```

本文档不新建第五个 Interaction Model，也不建立独立的 Planning Space、Safety Space、Authority Space 或 Assistance Space。

---

## 2. 运行心智模型与责任边界

### 2.1 Interaction Runtime 是两个边界串联，而不是一个 Agent Loop

一个最小 Interaction Decision runtime 可表示为：

```text
Reality / Current State
→ Decision Opportunity
→ Current Resolution
→ DecisionContext Snapshot
→ Pre-Reasoning Admissibility
→ Policy Reasoning
→ PolicyCandidate
→ Commit-Time Revalidation
→ PolicyOutcome
→ [Execute only]
   Post-Reasoning Admissibility
→ ActionIntent
→ Executor Effect-Time Check
→ ActionOccurrence | NotOccurred | Indeterminate
→ Factual History
→ New Decision Opportunity if relevant
```

这里存在两个必须分离的核心 boundary：

1. **Decision Boundary**：系统是否决定 Execute / NoIntervention / Defer；
2. **Effect Boundary**：被批准的 ActionIntent 是否真的跨越现实 effect boundary。

因此：

\[
DecisionCommit
\neq
RealityOccurrence
\]

Policy 可以决定行动，但只有 ActionOccurrence 才证明行动真实发生。

### 2.2 Decision Trigger 只创建重新判断机会

Decision Trigger 可以来自：

- 新 Event；
- 新 Observation；
- Learner Belief revision；
- Target / TargetAssessment change；
- Target Binding / External Obligation change；
- Context Authority change；
- Plan expiration / invalidation；
- Runtime Learner Condition change；
- tool availability change；
- timer / deadline；
- safety / security / operational signal；
- explicit learner request。

但：

\[
Trigger
\neq
Mandate
\]

触发只说明“当前世界可能值得重新判断”。它不说明一定要产生 learner-facing Action。

同一会话的常规 Decision Opportunity 遵循 §5.1 的串行轮次安排；触发到达不意味着立即启动另一条并行 Policy 链。用户主动中断与异常属于独立控制路径，不能把所有普通输入自动视为中断。

### 2.3 Interaction 不创建 Learner Belief

Interaction 可以读取 Evaluation 提供的 current Learner Belief、Target Assessment、Target Gap、Epistemic Gap，但不能在 Policy 中偷偷创建长期 learner judgment。

例如：

```text
Observation = ArithmeticMismatch
```

可以支持当前 Policy 决定：

```text
Elicit(CheckCurrentStep)
```

但不能在 Policy 内写：

```text
LearnerBelief = DivisionWeak
```

必须保持：

\[
InteractionPolicy
\ cannot\ create\ LearnerBelief
\]

### 2.4 Action Semantics 与 Action Selection 分离

Action Model 定义“DeerMind 有意能够做什么”；Policy 决定“此刻是否值得选择其中一个 Action”。

\[
ActionSemantics
\neq
ActionSelection
\]

Action ontology 可以定义某类行为会暴露什么信息、替代哪些认知工作、要求 learner 做什么、控制哪些交互生命周期；但 Action ontology 自身不能决定“现在应该做”。

### 2.5 Authority 约束 admissible set，不替代 Policy judgment

Context Authority、Governance、Safety Constraint、External Obligation 可以收紧当前 admissible action space，例如：

- 某些 Action 被禁止；
- 某些 Action 必须满足额外条件；
- 某些义务必须在一定时间内处理；
- 某些危险 effect 需要阻断。

但它们不能把 object-level learner Action 变成无条件执行命令。

\[
AuthorityDirective
\neq
PolicyBypass
\]

即使 Governance 批准一个 validation intent，learner-level runtime 仍需要基于当前 Context 选择 Execute / NoIntervention / Defer。

### 2.6 State change 不能自动升级成 Action

系统必须保持：

\[
TargetGap
\neq
EpistemicGap
\neq
Action
\]

以及：

\[
StateChange
\neq
DecisionMandate
\]

这条规则避免 Evaluation、Current Resolver、Scheduler 或外部 deadline 机制变成隐藏的第二 Policy writer。

### 2.7 Policy 是真实判断，不是 deterministic gate 的装饰

Deterministic system 的职责是 legality / authority / consistency / execution safety；Policy 的职责是 context-sensitive judgment。

如果 deterministic gate 同时重新编码“教育上是否应该提示”“何时应该复习”“什么解释最好”等大量 pedagogy 规则，那么 AI Policy 只剩建议层，真实业务判断重新隐藏在 if/else 中。

因此：

```text
Deterministic System:
  can this outcome legally and consistently take effect?

Interaction Policy:
  among legal possibilities, what is worth doing now?
```

---

## 3. Decision Objects 与正式运行合同

### 3.1 Decision Opportunity

`DecisionOpportunity` 表示系统存在一次重新进行 Policy 判断的合理机会。它不是正式 intervention command，也不保证一定产生新的 PolicyOutcome。

逻辑字段至少包括：

```text
DecisionOpportunity
├── OpportunityId
├── TriggerType
├── TriggerRef(s)
├── Subject / Scope
├── Purpose
├── EarliestEvaluationTime
├── Optional Deadline / Expiry
└── Correlation / Provenance
```

Decision Opportunity 可以被合并、去重、延迟或判定为无需决策，但不能被直接执行。

### 3.2 Decision Cycle

每次实际进行 Policy 判断，都形成一个独立 `DecisionCycle` identity：

```text
DecisionCycle
├── DecisionCycleId
├── OpportunityRef(s)
├── Purpose
├── DecisionContextRef
├── PolicyProtocolRef
├── ReasoningExecutionRef
├── CandidateRef
├── CommitResult
├── PolicyOutcomeRef
└── Audit / Timing
```

Decision Cycle 是历史 decision 事实的解释骨架，但不等于 Factual History 中的 learner-world Event。

### 3.3 Decision Context

`DecisionContext` 是一次 Policy reasoning 使用的 **purpose-bound coherent snapshot**。

它不是一个“把所有 learner 信息塞进去”的全局上下文，也不是新的 Source of Truth。

逻辑上可以包含：

```text
DecisionContext
├── Purpose / Subject / Scope
├── Conversation / ActiveTurn refs
├── Current activity purpose / assistance constraints + source refs
├── Current Observation(s)
├── InteractionState projection
├── LearnerBelief refs
├── LearningTarget refs
├── TargetAssessment / Gaps
├── Current TargetBinding projection
├── GoalIntent
├── ExternalObligation
├── AuthorityDirective / ContextAuthority
├── RuntimeLearnerCondition
├── AssistanceContext
├── PlanRef if relevant
├── Available Action Semantics
├── Runtime Tool Availability
├── Time / Environment
├── VersionContext
├── DependencySet
├── Authority / DataAuthority basis
└── ContextManifest / Provenance
```

不是每次 Decision 都读取全部字段。Context 必须遵守 Minimum Sufficient Context。

### 3.4 Decision Context 保留输入来源，不压成“综合状态”

Decision Context 中不同输入必须保留自己的来源与 semantic class：

| 输入 | Source / Owner | 不能被误解释为 |
|---|---|---|
| LearningTarget / ResponsibilityBoundary | Learning Space | learner preference |
| Learner Belief | Evaluation | Event fact |
| TargetAssessment / Gaps | Evaluation 基于产品目标与 Belief 的派生视图 | Action command |
| Observation | Interaction | Learner Belief |
| Interaction State | Interaction projection | factual source |
| Goal Intent | learner-originating runtime input | Learning Target |
| Target Binding projection | Interaction current projection | Target Definition |
| External Obligation | Product Context / Event | learner-owned Goal |
| Context Authority | Context Constitution / Governance | pedagogical judgment |
| Plan | Interaction Policy | future command |
| Runtime Tool Availability | Environment / Interaction | canonical tool semantics |

必须保持：

\[
GoalIntent
\neq
LearningTarget
\neq
ExternalObligation
\neq
Plan
\]

### 3.5 Pre-Reasoning Admissible Action Envelope

在 Policy reasoning 前，deterministic system 先解析当前**可被考虑**的 Action 上限：

```text
AdmissibleActionEnvelope
=
ActionSemantics
∩ ProductConstitution
∩ ContextAuthority
∩ 当前活动的帮助约束（结合活动目的、Task semantics、Target responsibility 与 Context Authority 解析）
∩ RuntimeToolAvailability
∩ DataAuthority
∩ SecurityEligibility
∩ LifecycleEligibility
```

这里的 `∩` 表示概念上的共同限制，不要求一个物理中央组件完成所有计算。

Pre-reasoning admissibility 的目的不是替 Policy 选择行动，而是防止模型把明显无权执行的结果当成正常候选。

Target Support / Responsibility Boundary 说明最终能力判断要求学习者承担什么，不直接禁止学习过程中暂时替代这些责任的支架。当前活动的帮助约束通过已有 InteractionState 与 DecisionContext 表达，并保留目的、适用的 Task / Context 规范及其 exact refs；它不是新的 canonical model，也不由 learner 请求自行授予权限。普通学习活动中，提示、演示或完整讲解可以进入候选范围，Policy 再判断是否值得采用；明确要求独立完成的活动则按其当前约束限制帮助。允许帮助不会降低 Target 标准，实际帮助对能力证据的影响仍由 Evaluation 解释。

### 3.6 Interaction Policy Protocol

Policy 如果使用 AI Reasoning Runtime，应通过明确版本化 `InteractionDecisionProtocol` 执行，而不是通用“下一步做什么” Prompt。

最小语义合同至少包括：

```text
InteractionDecisionProtocol
├── SemanticRole = InteractionPolicy
├── Objective
├── InputContract = DecisionContext
├── ContextPolicy
├── Allowed Candidate Types
│   ├── Execute(ActionCandidate)
│   ├── NoIntervention
│   └── Defer
├── AdmissibleActionEnvelope contract
├── Decision Criteria / Design Forces
├── MinimumSufficientIntervention rule
├── RationaleContract
├── Uncertainty / Failure Policy
├── ValidationPolicy
└── ProtocolVersion
```

Policy Protocol 不拥有 Learner Belief writer、canonical semantic change authority 或 factual authority。

### 3.7 PolicyOutcome

一次成功的 Policy Decision 的正式 outcome 只有三种高层语义：

\[
\boxed{
PolicyOutcome
=
Execute(ActionCandidate)
\;|\;
NoIntervention
\;|\;
Defer
}
\]

运行失败、Unauthorized、CandidateStale、NoCurrentValidState、ModelFailure 不属于这三个 outcome。

### 3.8 `Execute(ActionCandidate)`

`Execute` 表示 Policy 已经判断某个 Action 值得进入后续 effect authorization；它仍不是现实执行权限本身。

`ActionCandidate` 至少需要：

```text
ActionCandidate
├── ActionSemanticRef
├── Parameters
├── IntendedPurpose
├── IntendedSubject / Scope
├── Expected Interaction Effect
├── InformationDisclosure description
├── CognitiveWorkSubstitution description
├── Relevant Tool / Resource requirements
├── Rationale
├── DecisionContextRef
└── Candidate Provenance
```

### 3.9 `NoIntervention`

`NoIntervention` 是积极、正式、可审计的决策：当前不采取面向 learner 的 Action。

\[
NoIntervention
\in
CandidatePolicyOutcomes
\]

它必须有 reason，例如：

- 当前 learner 可独立继续；
- intervention value 不足以覆盖 attention / substitution cost；
- 更自然的未来 opportunity 更合适；
- 当前已有足够支架；
- learner 明确拒绝，且没有更高合法 authority 要求继续；
- 当前 uncertainty 存在，但获取更多信息的价值不足。

系统不能把“没有响应”“模型超时”“队列丢消息”当成 NoIntervention。

### 3.10 `Defer`

`Defer` 表示当前不执行，但明确说明未来重新评估条件。

```text
Defer
├── Reason
├── ReevaluationCondition
├── Optional EarliestTime
├── Optional Deadline
└── Dependency / Context refs
```

关键约束：

\[
Defer
\neq
SuspendedActionCommand
\]

Defer 不保存一个等待自动执行的 ActionIntent。条件满足后，只产生新的 Decision Opportunity；系统必须重新形成 current DecisionContext 并重新 Policy。

### 3.11 Plan

Plan 是 Interaction Policy 的跨时间策略产物：

```text
Plan
├── PlanId / Revision
├── Purpose / Scope
├── Target / Binding refs
├── Strategy / Opportunity structure
├── Dependencies
├── VersionContext
├── CreatedFromDecisionRef
├── Lifecycle
│   ├── Active
│   ├── Stale
│   ├── Superseded
│   ├── Abandoned
│   └── Completed
└── ReplanningConditions
```

必须保持：

\[
Plan
\neq
Event
\neq
LearnerBelief
\neq
LearningTarget
\neq
TargetBinding
\neq
Obligation
\]

Plan 可以组织未来 opportunity，但不能携带未来 execution authority。

### 3.12 Runtime Learner Condition

Runtime Learner Condition 描述当前交互期间对短期状态的带不确定性判断，例如：

- fatigue；
- current willingness；
- temporary cognitive overload；
- affect；
- attention residual；
- transient frustration。

它必须：

- 有当前 episode / time scope；
- 保留 uncertainty / source；
- 可以 stale / expire；
- 不自动跨 episode 继承；
- 不直接成为 Evaluation Learner Belief。

\[
RuntimeLearnerCondition
\neq
LearnerBelief
\]

### 3.13 ActionIntent

`ActionIntent` 是 `Execute(ActionCandidate)` 通过 deterministic post-reasoning admissibility 后形成的**受限现实执行能力**。

```text
ActionIntent
├── IntentId
├── Exact ActionSemanticRef / Version
├── Exact Parameters
├── Subject / Resource / Scope
├── DecisionCycleRef
├── PolicyOutcomeRef
├── AuthorityBasis
├── DataAuthorityBasis if needed
├── Security / Execution Constraints
├── Preconditions
├── Expiry
├── IdempotencyKey
├── ExecutorTarget
└── Provenance / Audit refs
```

ActionIntent 不能被 Executor 重新解释成“类似的另一个动作”。

### 3.14 ActionOccurrence / NotOccurred / Indeterminate

Executor 的现实结果至少区分：

```text
Occurred
NotOccurred(reason)
Indeterminate(reason)
```

只有 `Occurred` 可以进入 Runtime & Event Architecture 定义的 ActionOccurrence factual admission。

`NotOccurred` 例如：

- precondition invalidated；
- authority revoked；
- learner session ended；
- transport rejected；
- UI client unavailable；
- resource no longer exists。

`Indeterminate` 表示 effect 是否真实发生无法可靠确认，不能猜成 Occurred，也不能简单等于 Failed。

### 3.15 Information Disclosure 与 Cognitive Work Substitution

Action 必须能够描述两个不同维度：

1. **Information Disclosure**：系统向 learner 暴露了哪些信息；
2. **Cognitive Work Substitution**：系统替 learner 完成了哪些本应由 learner 承担的认知工作。

二者不能合并成粗糙的 `hint_level`。

例如同一句提示可能只暴露一个方向，也可能直接替 learner 完成 Strategy Selection。Evaluation 后续根据具体 Claim / Responsibility Boundary 判断 contamination；Interaction 只负责真实描述实际发生的 exposure semantics。

### 3.16 Assistance Exposure Lineage

Assistance 的权威链必须基于**实际发生**的 Action：

```text
ActionIntent
→ ActionOccurrence
→ Occurred Payload / Disclosure
→ Exposure Lineage
→ Learner Response
→ Observation
→ Claim-relative Evidence
```

必须保持：

\[
SelectedAssistance
\neq
OccurredAssistance
\]

\[
OccurredAssistance
\neq
LearnerUsedAssistance
\]

\[
AssistanceOccurred
\neq
EvidenceContaminated
\]

Interaction 不维护一个全局 `assisted=true` learner state。

### 3.17 工具四层语义

工具相关运行语义必须分成四层：

1. **Task Canonical Tool Semantics**：完成 Task 在领域规范上允许 / 要求什么工具，属于 Domain；
2. **Target Support / Responsibility Boundary**：Target 是否允许把某项认知责任长期外部化，属于 Learning Target；
3. **Runtime Tool Availability**：当前现实中工具是否可用，属于 Interaction / Environment；
4. **Occurred Tool Use**：本次 learner / system 实际是否使用，属于 factual occurrence / exposure lineage。

\[
TaskTool
\neq
TargetSupport
\neq
RuntimeAvailability
\neq
OccurredToolUse
\]

AI Runtime 内部 Reasoning Tool 使用也不能被误记成 learner Task tool use。

---

## 4. Policy Judgment 与行动选择

### 4.1 Policy 使用四阶段决策结构

Interaction Policy 概念上遵循：

```text
1. Admissibility
2. Value / Cost Assessment
3. Minimum Sufficient Outcome Selection
4. Rationale
```

这四层不要求四个独立服务，但语义上必须可区分。

### 4.2 Admissibility：先问“能不能考虑”

Admissibility 处理不可被普通 reward 抵消的制度性限制，包括：

- Product Constitution；
- current Context Authority；
- learner stop / refusal 在当前 scope 的效力；
- Safety / Security restriction；
- Data Authority；
- 当前活动的帮助约束及其规范来源（见 §3.5）；
- Action semantic version eligibility；
- tool / resource availability；
- lifecycle / expiry。

一个 Outcome 不 admissible，就不应进入“价值多高”的比较。

### 4.3 Value / Cost Assessment：再问“值不值得”

对 admissible outcomes，Policy 可以综合：

- 当前学习价值；
- 信息价值；
- 现实义务价值；
- urgency / deadline；
- learner Goal Intent；
- attention cost；
- cognitive substitution cost；
- interruption cost；
- opportunity cost；
- future natural opportunity；
- learner current condition；
- uncertainty；
- disconfirmation value。

这些维度不是一个要求冻结统一数值权重的全局 reward function。

### 4.4 `Admissible != WorthDoing`

一个 Action 可以完全合法，却不值得执行。

例如：系统有权给 Hint、Hint 满足当前活动的帮助约束、工具也可用，但 learner 正在独立推进且无高价值错误；此时 NoIntervention 可能优于 Hint。

因此：

\[
Admissible
\not\Rightarrow
Execute
\]

### 4.5 Minimum Sufficient Intervention

Policy 的选择原则不是“干预越少越好”，而是：

> 在足以解决当前高价值问题的候选方案中，优先选择 attention cost 更低、Cognitive Work Substitution 更少、learner cognitive ownership 更完整的方案。

\[
Minimal
\neq
Insufficient
\]

如果低强度 intervention 不能解决当前真实问题，则更强 Action 可以是合理选择。

### 4.6 Intervention 必须与 NoIntervention 竞争

每次 Policy reasoning 都必须真实包含 NoIntervention 可能性：

\[
InterventionMustJustifyItselfAgainstNoIntervention
\]

这不是 UI 选项，而是系统层 anti-engagement pressure。

### 4.7 Gap 不直接触发学习或测评动作

Target Gap 表示“当前能力认识相对于 Target requirement 存在差距”；Epistemic Gap 表示“系统不知道足够多”。两者都只提供 decision-relevant information。

```text
TargetGap
→ maybe practice / explain / wait / no intervention

EpistemicGap
→ maybe elicit / assess / wait for natural evidence / no intervention
```

新增 Observation 的价值不足时，UNKNOWN 可以继续存在。

### 4.8 Active Assessment 属于 Policy

Active Assessment 不是 Evaluation 自动触发的测评模块。

它的正确 ownership 是：

```text
Evaluation:
  expresses EpistemicNeed / Gap

Interaction Policy:
  decides whether obtaining new Observation is worth the cost now
```

因此：

\[
EpistemicGap
\not\Rightarrow
ActiveAssessment
\]

### 4.9 外部义务与学习价值保持分离

学校作业、考试 deadline、机构要求、工作任务等现实义务可以影响 Policy，但不能被洗成 learner Goal 或 Learning Target。

\[
LearningValue
\neq
ObligationValue
\]

Policy 可以为了现实义务帮助 learner 完成任务，同时仍需要控制不必要的认知替代。

### 4.10 Goal Intent 不创建 Target

learner 说“我想今晚把作业做完”可以形成 Goal Intent；这不自动创建新的 Learning Target，也不改变已有 Target responsibility boundary。

同样，Policy 可以提出 `TargetCandidate`，但正式 Target Definition 仍属于 Learning Space 的受控定义与发布路径。

#### 独立诊断转入教学

学习者在独立诊断中明确请求讲解，应作为 learner-originating Event 进入运行事实，并表达结束诊断、转入教学的意图。在允许自主切换的活动中，Interaction 应结束本次独立诊断并响应教学请求；具体帮助仍经过 Policy、Commit 与 Action execution。若适用的外部测评约束限制转换，系统说明限制，不通过改变 Purpose 绕过 authority。活动切换不修改 Target Definition，也不自动写入 Learner Belief。

普通讲解请求按会话输入顺序处理，在轮到该输入时执行上述转换；若上一轮仍在运行，请求先排队，不因到达就自动取消上一轮。用户主动中断当前处理属于另一条控制路径，不与普通讲解请求的排队语义混同。

请求、切换决定、切换实际生效和帮助实际暴露必须能够分别追溯，沿用现有 Event、PolicyOutcome、ActionIntent / ActionOccurrence 和 InteractionState 合同。活动转换涉及的 Control Action 仍须真实生效才更新相应运行投影；仅有 Policy 意图不能充当已完成转换。转入教学后，系统根据新的活动目的与约束形成新的 DecisionContext，并重新解析行动范围。影响 admissibility 的目的、约束及切换状态必须进入 critical dependency / execution precondition 检查，使切换前的候选或 Intent 不能绕过重新验证继续执行。

最小语义检查应覆盖：自主切换被允许时诊断结束并可进入教学；外部约束不允许时不会获得越权帮助；请求已发生但讲解尚未暴露时不生成虚构的 Assistance；实际暴露后按 Claim-relative 条件解释表现。请求前的证据不得因后续转换被整体作废，诊断证据不足时允许保持未知。重新开始独立机会也不清除已有 exposure lineage；具体 Evidence 判断遵循 Evaluation Space §5.2–§5.3。

### 4.11 Context Authority 不创建 Epistemic Evidence

合法 authority 可以改变可执行范围，但不能改变 learner 能力认识：

\[
AuthorityOverride
\neq
EpistemicEvidence
\]

“必须完成作业”不能被解释成“learner 已掌握”，也不能因为 authority 强就直接写 Evidence / Belief。

### 4.12 Planning 属于 Policy，但 Plan 不拥有未来 authority

多时间尺度 Planning 可以组织：

- 当前行动；
- 近期机会排序；
- 未来需要等待的自然 evidence opportunity；
- 已绑定 Target 间的优先关系；
- 支架逐步撤除；
- deadline / obligation 协调。

但每个未来现实 effect 仍必须进入新的 Decision Cycle。

因此：

\[
Plan
\neq
FutureCommandQueue
\]

### 4.13 Fade-out 是 trajectory，不是动作类型

当 learner 对 Target 要求其独立承担的认知责任有更强证据时，Policy 应降低不必要 Cognitive Work Substitution，并增加独立 opportunity / NoIntervention。

但如果 Target 本来允许长期工具外部化，就不应为了“独立”机械撤除合法工具。

### 4.14 Policy 必须保留合理反证机会

Learner Belief 会影响未来决策，但不能长期封闭能够推翻自己的机会。

如果已有 `Belief = Weak` 导致系统持续只分配低 challenge task，未来数据会被 Policy 自己塑造，系统可能用自己制造的数据继续证明“weak”。

因此 Policy 至少需要在长期 opportunity allocation 中保持：

- 适当 challenge opportunity；
- independent-performance opportunity；
- transfer / delayed opportunity；
- 与当前 Belief 不一致的可观察空间。

该原则不要求当前版本冻结统一的“反证配额”算法，但必须进入 audit / Evolution signals。

### 4.15 Engagement 不是顶层目标

系统不能因为“更多交互”“更多点击”“更多 session”就认为 Policy 更好。

\[
MoreEngagement
\not\Rightarrow
BetterPolicy
\]

当 learner 能独立继续、当前问题不值得打扰或新增 assessment 价值不足时，最优 Policy 可以是 NoIntervention。

---

## 5. 动态运行：从 Decision Opportunity 到 Action Occurrence

### 5.1 Decision Cycle 主链

同一会话的常规处理严格串行：同一时刻只有一个活动轮次，按输入接纳顺序完成该轮所需的理解、校验、决策、提交和行动结果处理，再开始下一轮。只串行调用 LLM、却允许上一轮的 Action 执行链与下一轮重叠，不满足此合同。轮次完成应对应明确的 outcome / execution result；不行动或等待未来机会可以结束当前轮次，不能遗留一个稍后自行执行的旧决策。

处理中到达的普通消息可以先记录收到事实并排队，但不得提前启动该输入的 Observation / Policy 链，也不因排队本身使当前 DecisionContext stale。Interaction 必须区分已接收、待处理和当前轮次已纳入的输入；Context、InteractionState 与重建使用相同的处理边界，不能查询“最新消息”时把排队内容提前混入当前轮次。收到时间与处理顺序分别保留，不能为了串行执行改写原始 Event 时间。

异常或用户主动中断可以使当前轮次进入独立的终止 / 恢复处理。确认旧轮次已结束，或其未完成执行已被隔离、不能再自行产生新 effect 后，才启动下一常规轮次；已发生或无法确认的 effect 沿用事实与 reconciliation 合同，不能因中断而假定从未发生。本节不展开中断的交互形式和恢复策略，也不要求对每条排队消息另开并行 LLM 判断。

串行范围是会话，不是整个 learner 或全系统。跨会话共享状态、外部 correction、版本与权限变化仍须遵循 currentness 与 effect-time 检查；它们不创建同会话并行的常规轮次。相关变化需要重新决策时，由当前轮次收束后再调度新的 Decision Cycle。具体队列、锁或调度器不在此冻结。

```text
Trigger / Opportunity
→ resolve purpose + subject + scope
→ CurrentResolver
→ bind current semantic inputs
→ resolve current authority / data authority / lifecycle / security
→ build DecisionContext
→ freeze VersionContext + DependencySet + ContextManifest
→ resolve pre-reasoning AdmissibleActionEnvelope
→ InteractionDecisionProtocol
→ PolicyCandidate
→ structural / grounding / semantic validation
→ commit-time revalidation
→ PolicyOutcome
```

如果结果是 `NoIntervention` 或 `Defer`，Decision Cycle 在这里形成正式 outcome，不继续创建 ActionIntent。

如果结果是 `Execute(ActionCandidate)`：

```text
PolicyOutcome
→ post-reasoning admissibility
→ ActionIntent
→ Executor
→ effect-time precondition check
→ Occurred | NotOccurred | Indeterminate
→ factual admission if Occurred
→ Event History
```

### 5.2 为什么需要 pre- 和 post-reasoning 两次 admissibility

Pre-reasoning gate 用于限制模型只在当前合法搜索空间内 reasoning；post-reasoning gate 用于验证具体 Candidate 在 reasoning 完成后仍然合法。

两者解决不同问题：

```text
Pre:
  what may be considered?

Post:
  may this exact selected candidate obtain execution authority now?
```

Reasoning 期间 authority、tool availability、Binding、security state 都可能变化，因此 pre-check 不能替代 post-check。

### 5.3 Policy Commit-Time Revalidation

正式提交 PolicyOutcome 前至少重验：

- DecisionContext 的 CURRENT dependencies；
- expected head / concurrent decision conflict；
- semantic version compatibility；
- Target / Binding / Obligation currentness；
- Authority；
- Data Authority；
- lifecycle；
- security eligibility；
- candidate Action semantic availability。

若关键依赖已变化：

```text
Policy reasoning succeeded
→ CandidateStale
→ no PolicyOutcome effect / no ActionIntent
→ new Decision Opportunity
```

### 5.4 `CandidateStale` 不自动等于新的 Policy 结果

CandidateStale 是 consistency failure，不是：

- NoIntervention；
- Defer；
- Execute；
- learner refusal；
- model uncertainty。

系统可以调度新的 Decision Cycle，但不能把 stale candidate 静默“修补”成 current。

### 5.5 ActionIntent Commit 后的并发边界

ActionIntent 一旦合法形成，不要求后续每个 Event 都重新运行 Policy。

否则实际执行会被高频 Event 永久阻塞。

Executor 只检查 ActionIntent 声明的 deterministic effect-time preconditions：

- intent 未过期；
- authority / data authority 未撤销；
- subject / resource 仍合法；
- required session / UI channel 仍存在；
- safety / security block 未出现；
- declared semantic precondition 仍成立。

因此：

\[
ExecutionPreconditionCheck
\neq
PolicyReexecution
\]

### 5.6 Effect-time precondition 失效

```text
ActionIntent
→ Executor
→ precondition failed
→ NotOccurred:PreconditionInvalidated
```

不能：

- 自动换成另一个 Action；
- 自动降低/提高 hint level；
- 自动改写 parameters；
- 让 Executor 临时重做 pedagogy decision。

如果需要另一个 Action，应重新进入 Policy。

### 5.7 ActionOccurrence 重新进入事实闭环

ActionOccurrence 形成后，它与其他 Event 一样进入 Factual History，并成为：

- 后续 Observation grounding；
- Assistance Exposure Lineage；
- Evaluation Evidence context；
- future DecisionContext；
- audit / replay；
- Evolution signal。

这形成：

```text
Decision
→ Intent
→ Reality Effect
→ Event
→ New Understanding
→ Future Decision
```

### 5.8 Informational Action 的最小 effect boundary

对于 learner-facing informational Action，当前最小系统语义可以是“client-confirmed render / delivery crossing”，而不是“learner 已看到 / 已理解”。

必须保持：

\[
Rendered
\neq
Perceived
\neq
Understood
\neq
Used
\]

如果未来产品能够获得更强 exposure attestation，可以扩展 occurrence semantics，但不能把无法观察的 learner internal state 写成事实。

### 5.9 Defer 的重新进入

Defer 的 `ReevaluationCondition` 满足时：

```text
condition satisfied
→ new DecisionOpportunity
→ resolve fresh DecisionContext
→ new Policy decision
```

不是：

```text
condition satisfied
→ execute old ActionCandidate
```

### 5.10 Plan 驱动的是 Opportunity，不是 Effect

Plan 可以在某时间点、某自然学习场景或某 deadline 条件下产生 Decision Opportunity，但不能直接创建 ActionIntent。

这保证 Target、Belief、Binding、Authority 在未来已经变化时，旧 Plan 不会继续自动执行。

---

## 6. Assistance、Tool、Planning 与跨时间语义

### 6.1 Assistance Context 是投影，不是 exposure 事实源

`AssistanceContext` 可以为 Policy / Evaluation 快速总结当前 episode 已经发生的支架与信息暴露，但其 authority 必须来自 ActionOccurrence / occurred payload lineage。

\[
AssistanceContext
\neq
AuthoritativeExposureFact
\]

如果 projection 丢失，可以 rebuild；如果 factual lineage 缺失，则必须显式 `ExposureUnknown`，不能把“没有记录”当成“没有帮助”。

### 6.2 Partial Disclosure 是一等情况

Action 原计划暴露完整提示，但传输中断、UI clipping、分段展示或 learner 提前离开，都可能只发生 partial disclosure。

系统需要能够记录实际发生的 payload / disclosure，而不是简单按 ActionType 推断 exposure。

```text
SpecifiedDisclosure
!=
OccurredDisclosure
```

### 6.3 Interaction 描述 substitution，Evaluation 判断 contamination

Interaction 负责：

- 哪些信息被暴露；
- 哪些 cognitive work 被系统替代；
- 何时发生；
- 对哪个 Task / opportunity；
- lineage 是否完整。

Evaluation 再相对于具体 Claim / Responsibility Boundary 判断：

- Supports；
- Contradicts；
- Discriminates；
- NonInformative；
- contaminated / partially informative。

Interaction 不预先把一次 Action 标记成“污染全部 Evidence”。

### 6.4 Runtime Tool Availability 是 current operational dependency

如果工具在 Policy reasoning 时可用、ActionIntent effect 时已不可用：

```text
DecisionContext: ToolAvailable
→ ActionIntent
→ Executor check: ToolUnavailable
→ NotOccurred
```

这不改变 Task canonical tool semantics，也不改变 Target support boundary。

### 6.5 AIRuntime ToolUse 与 learner ToolUse 分离

Policy reasoning 内部调用 search / calculator / code tool 只是 AI execution provenance。

\[
AIRuntimeToolUse
\neq
LearnerTaskToolUse
\]

它不自动进入 Assistance Exposure Lineage，除非其结果进一步通过 learner-facing Action 真实暴露给 learner。

### 6.6 Plan invalidation

以下变化通常使相关 Plan stale / require reevaluation：

- Target Definition / version change；
- Target Binding change；
- External Obligation change；
- Learner Belief / TargetAssessment change；
- Context Authority change；
- Runtime tool availability long-term change；
- Plan deadline / expiry；
- relevant semantic version incompatibility。

但：

\[
PlanInvalidation
\neq
PastDecisionInvalidation
\]

已经发生的 ActionOccurrence 不被重写。

### 6.7 Plan recovery

进程重启、workflow resume 后，Plan 可以从 durable revision 恢复，但必须重新 resolve：

- current Target / Binding；
- current Belief / Assessment；
- current Authority / Data Authority；
- current versions；
- lifecycle；
- current environment。

旧 DecisionContext snapshot 不能直接成为未来 current context。

### 6.8 Runtime Learner Condition 不跨时间固化

短期 fatigue、frustration、willingness 可以影响当前 Policy，但如果系统将其长期保存为“这个 learner 总是懒 / 容易分心”，就越过了 Evaluation boundary。

跨 episode 需要长期认识时，必须由新的 Observation / Evidence / Evaluation 路径形成 Belief，而不是 Interaction State carry-over。

### 6.9 Cross-time persistence boundary

Interaction Runtime 允许跨时间持久化：

- committed PolicyOutcome / Decision record；
- Plan revision；
- ActionIntent / execution result；
- ActionOccurrence factual refs；
- Assistance lineage refs；
-必要 WorkflowCheckpoint；
- version / dependency / provenance metadata。

它不允许把任意对话摘要或 Agent working memory 当成 authoritative current state。

---

## 7. Failure、Concurrency、Recovery 与 Audit

### 7.1 Policy non-resolution 与 runtime failure 分离

合法的 policy / cognition non-resolution 可以包括：

- insufficient context；
- competing reasonable actions 无法区分；
- uncertainty 太高；
- no worthwhile action。

但需要区分：

```text
No worthwhile action → NoIntervention
Need explicit later reevaluation → Defer
Model / Tool / Protocol failed → RuntimeFailure
Context not current → CandidateStale / NoCurrentValidState
No authority → Unauthorized
```

ModelFailure 不允许默认映射为 NoIntervention。

### 7.2 NoCurrentValidState

如果 Policy 所需 critical inputs 没有 current-valid revision：

```text
CurrentResolver
→ NoCurrentValidState
→ Decision cannot proceed as normal
```

系统可以：

-等待 recompute；
-触发合法的 evidence / state refresh opportunity；
-降低 capability；
-返回明确 unavailable / defer-like operational state。

但不能偷偷 fallback 到已知 invalid old state。

注意：若未真正运行 Policy，就不能把 operational unavailable 伪装成正式 `Defer` PolicyOutcome。

### 7.3 Policy Model Failure

Policy model timeout、provider failure、invalid structured output、tool failure 等属于 Reasoning Runtime Failure。

除非存在**正式版本化、被批准的 FallbackPolicyProtocol**，否则不能直接使用隐藏 heuristic 生成 Execute / NoIntervention / Defer。

\[
RuntimeFailure
\neq
PolicyOutcome
\]

### 7.4 Concurrent context change

同会话普通新输入按 §5.1 排队；本节处理另一会话或独立 owner 已提交的共享状态变化，以及当前 authority / version / lifecycle 变化。典型路径：

```text
C1 = DecisionContext(Belief@r3, Binding@b2)
→ Policy reasoning
→ meanwhile Belief@r4 commits
→ post reasoning revalidation
→ CandidateStale
→ no ActionIntent
→ new DecisionCycle with current context
```

这不需要跨会话锁住整个 learner runtime；单会话严格串行是已选择的正常处理规则，不属于架构假设被否定。

### 7.5 Concurrent Policy commits

单会话常规调度不产生并行轮次；如果不同会话 / 执行来源仍对同一正式 scope 产生互斥 Decision Candidate，需要 explicit expected-head / decision conflict semantics，而不是 Last-Write-Wins。

例如：

```text
D1 and D2 both resolve decision-head h7
D1 commits h8
D2 tries h7
→ CommitConflict
```

是否允许同 scope 并行非互斥 decisions，由下位 implementation / ADR 根据 effect domain 进一步定义，但不能静默覆盖。

### 7.6 ActionIntent 过期

ActionIntent 的有效期通常比 Plan / PolicyOutcome 更短。过期后：

```text
ActionIntent Expired
→ Not executable
→ optional new DecisionOpportunity
```

Expired 不等于 Invalid，也不改变历史 PolicyOutcome。

### 7.7 Executor 结果不确定

若网络断开后无法确认 client 是否已展示内容：

```text
ActionIntent
→ transport ambiguous
→ Indeterminate
```

系统不得自动 retry 产生双重 exposure，除非 idempotency / reconciliation contract 能证明安全。

Indeterminate 需要进入 reconciliation / audit，并对后续 Assistance Exposure 保持 `ExposureUnknown` 或 bounded uncertainty。

### 7.8 Retry 不能制造新的 pedagogy decision

Executor retry 只允许重试**同一个 exact ActionIntent**，且必须满足 idempotency 与 current execution preconditions。

如果需要改变 Action 语义、参数或支架强度，就必须重新 Policy。

### 7.9 Degraded Mode

Degraded Mode 可以：

- 禁止高风险 Action；
- 暂停需要 unavailable dependency 的 Policy；
- 减少 tool / model capability；
- 返回明确 operational unavailable。

但不能：

- 把 model failure 当 NoIntervention；
- 把 old Plan 自动执行；
- 放宽 authority；
- fallback 到 invalid Belief；
- 使用 undocumented pedagogy heuristic。

### 7.10 Decision Audit

每个正式 Decision Cycle 至少要能够解释：

- 为什么产生此次 Decision Opportunity；
- 使用了哪些 exact current inputs；
- 当时有哪些 Action admissible / unavailable；
- Policy 使用哪个 Protocol / model execution；
- 产生了什么 Candidate；
- 为什么选择 Execute / NoIntervention / Defer；
- commit-time revalidation 是否通过；
- 如果 Execute，ActionIntent 的 authority / precondition 是什么；
- Executor 最终发生了什么；
- 如果发生 Assistance，实际暴露了什么。

Audit 用于解释 past effect，不是 future authority credential。

### 7.11 Rationale 不进入 learner epistemic truth

Policy rationale 可以说明“因为 learner 已连续两步独立推进，所以本次 NoIntervention”，但 rationale 本身不是 Evidence 或 Belief。

\[
PolicyRationale
\neq
Observation
\neq
Evidence
\neq
Belief
\]

### 7.12 Opportunity allocation audit

长期运行必须能够审计：

- 某 learner / subgroup 被分配的 challenge opportunity；
- independent-performance opportunity；
- assessment opportunity；
- support / scaffold trajectory；
- NoIntervention / Defer frequency；
- prior Belief 是否持续缩窄未来可观察空间。

这些 audit signal 可以进入 Evolution，但不能直接成为 learner Belief。

---

### 7.13 失败轮次收束与后续学习请求

单次尝试失败与整个轮次终止必须分开。Observation 或 Policy 候选不合格、必需校验失败或执行失败时，先记录绑定该轮、Context、Execution 及已有候选的失败依据；该失败尝试不能提交或派发。当前 Protocol 允许时，可在同一活动轮次内按预算有界重试，创建新的 Execution，并重新检查当前输入、权限和必需校验。新生成内容使用新的候选标识；重新检查未改变的候选也必须绑定 exact revision，失败记录不能充当通过依据。重试期间普通后续输入继续排队。

只有在明确不可恢复、允许的重试或预算耗尽、用户中断，或执行合同规定的其他终止条件成立时，才关闭整个旧轮的提交与新增派发资格。终止后的迟到模型输出只供审计，不恢复资格。失败不是 NoIntervention 或 Defer，不制造成功 PolicyOutcome；已经派发的行动及其迟到发生事实仍须按执行合同处理。

新输入先记收到事实再排队，不提前理解。没有动作派发时可以明确结束旧轮；存在在途动作时，处理其结果或按执行合同确认已结束或隔离，防止旧执行自行产生新 effect 后才释放队列。已经发生、部分发生和结果未知均保留；等待足够久不是停止确认。当前局部证据仅覆盖同步 mock 返回后的收束，远程停止、迟到效果对账和崩溃恢复仍需后续合同与验证。

旧轮收束后，后续学习请求按新的请求 Profile 开始。新 Context 可读取获准原题和原始作答，不能把失败 Observation、原始模型附言或审计汇总当作正式依据；必需材料缺失仍须 non-resolution。这样继续交互不依赖于把旧候选改判合格，也不让新请求自动改变活动或取得讲解权限。

若 Policy 选择获准 Control，其候选、校验、提交、Intent、实际转换确认和结果处理分别完成。仅成功 ActivityTransitionOccurred 被处理后，才能按新活动和当前权限重新组装 Context、形成新教学候选并校验执行。Control 失败、未知或普通展示不能开启该继续路径。实际讲解披露另按执行确认记录，新题响应也不自动证明独立掌握。

后续候选的来源随声明目的装配：若讲解定位或纠正具体作答，其内容校验必须取得相应原题与原始作答；一般概念讲解则提供其 Profile 所需的知识或任务依据，不要求不存在的先前作答。实际帮助发生后的 Policy 必须取得用途相关的 ActionOccurrence 及披露来源，不能只靠活动名称或学习者自述推断支持条件。新题号或新 episode 不自动清除近时帮助的相关性；必要来源缺漏不能由语义 PASS 补足。当前固定讲解、mock 效果、脚本 Evaluation 以及 E1/X5 结果的限制见[统一 Validation Report](spike/DeerMind_Architecture_Validation_Report_v0.1.md)。

## 8. 与相邻 Work Package 的契约与 Pre-Validation Closure

### 8.1 Runtime & Event Architecture

Interaction Runtime 从 Event / Factual History 获得：

- learner / external occurrence；
- ActionOccurrence；
- source / time / correlation / correction provenance；
- Target Binding occurrence grounding。

Interaction 产生真实 Action effect 后，通过 Event Architecture 的 factual admission 形成 ActionOccurrence。

Interaction 不自己定义“事实发生”的 authority。

### 8.2 AI Reasoning Runtime

AI Runtime 提供：

- `InteractionDecisionProtocol` execution；
- Decision Context assembly / manifest mechanism；
- Authority Envelope；
- Runtime Decision Candidate；
- Tool runtime；
- ReasoningExecutionRecord；
- model / protocol / tool provenance。

Interaction 提供 semantic ownership：

- 什么是 Policy；
- Policy 可读什么语义；
- 输出三类 outcome；
- 什么是 Action / Plan；
- 哪些结果允许进入 Interaction formal standing。

\[
AIReasoningRuntime
\neq
InteractionPolicyOwner
\]

### 8.3 State / Dependency / Invalidation

State Runtime 为 Interaction 提供：

- current-valid inputs；
- DecisionContext coherent snapshot；
- exact dependency；
- PINNED / CURRENT semantics；
- stale detection；
- commit-time revalidation；
- Plan / projection invalidation；
- recovery / recompute support。

Interaction 负责定义“哪些变化在 Interaction 语义上意味着什么”，State Runtime 负责执行一致性机制。

### 8.4 Domain 与 Learning Space

Domain 提供 ProblemTemplate、SolutionTemplate、KC、知识 grounding、问题工具条件与结构对应关系；Learning Space 提供材料及映射、LearningTarget、范围和支持责任。两者各自的身份、版本、适用 scope 与当前 binding 必须可分辨，Interaction 不拥有其规范写入权。

DecisionContext 按当前用途装配具体问题的实际来源、绑定参数、呈现条件与实际帮助，不从参考方法合成学习者轨迹。模板结构对应可以影响选题，但不能直接产生重复题禁令、强制复习或能力结论。是否再次检测、换表示、讲解或等待，由 Policy 结合有效 Evidence / Belief、目标和当前负担决定。

学习活动采用 SolutionTemplate 的分支、验证、回退或循环时，具体执行仍受当前活动、预算、退出与中断合同约束；Domain 方法不是一个不经 Policy 的行动程序。

### 8.5 Evaluation Space

Evaluation 提供：

- Learner Belief；
- Target Assessment；
- Target Gap；
- Epistemic Gap；
- uncertainty / epistemic status。

Interaction 可以用这些信息做 Decision，但不能写回 Learner Belief。

真实 Action exposure 通过 factual lineage供 Evaluation 形成 claim-relative Evidence context。

### 8.6 Version / Replay Work Package

本专项要求 Version / Replay 后续必须支持：

- Policy Protocol / Action semantics / Plan / DecisionContext 的 version binding；
- in-flight Decision pinning；
- activation change 后 future decision resolution；
- historical Decision reconstruction；
- semantic reinterpretation 不改写 past ActionOccurrence；
- partial replay 下 exposure / rationale completeness 的明确表达。

Version 专项决定完整 compatibility / migration contract；本文档不建立全局 SystemSemanticVersion。

### 8.7 Evolution / Governance

Interaction 向 Evolution 提供：

- decision / rationale / alternative / outcome history；
- opportunity allocation；
- assistance exposure；
- NoIntervention / Defer trajectory；
- policy failure / instability；
- target / authority projection behavior；
- Action / Policy semantic version provenance。

Governance 可以授权 validation intent、canonical Policy revision、Action semantics revision 或 authority change，但不能直接替代 learner-level Policy judgment。

### 8.8 Authority / Data Authority / Security

Interaction 使用这些横切 resolver 的结果，但不吸收其 ownership。

`AuthorityEnvelope` 是 reasoning 上限；`ActionIntent` 才是面向 exact effect 的 bounded execution capability；Executor backend 仍独立 enforcement。

### 8.9 Focused Design Closure 判断

本专项的历史 v1.0 合同曾与总体及其余五项专项完成一致性评审；当前 v1.1 在此基础上更新领域与产品输入合同，未重办旧 Gate。Gate E/F 的逐项依据及能力分期见[Phase 6 证据评审](DeerMind_System_Design_Evidence_Review_v1.0.md)，实验范围见[统一 Spike Validation Report](spike/DeerMind_Architecture_Validation_Report_v0.1.md)。该关闭指可实施设计完成，不证明生产质量、可靠率或规模能力。

### 8.10 当前保留的 Architecture Assumption

与本专项直接相关的高风险 Assumption：

**AA-D01 — Exposure Lineage Sufficiency**  
`ActionOccurrence + occurred payload / disclosure + ordered lineage` 足以支持 Assistance Exposure 重建，不需要另建独立 durable AssistanceExposureModel。

**AA-D02 — Claim-Relative Contamination**  
Evaluation 可以基于实际 exposure lineage 与 Claim / Responsibility Boundary 做 claim-relative contamination，而不需要全局 `assisted` learner state。

**AA-E01 — AI Policy Judgment vs Deterministic Legality**  
AI 可以承担真实 pedagogy / runtime Policy judgment，而 deterministic layer 只控制 legality、authority、commit 与 execution，不需要重新硬编码大量 pedagogy。

**AA-E02 — Snapshot + Revalidation Concurrency**  
在同会话常规轮次严格串行的前提下，coherent DecisionContext snapshot + commit-time revalidation 足以处理跨会话共享状态或外部 authority / version 等变化，不需要跨会话锁住整个 learner runtime。

AA-D01/AA-D02在既有mock披露与脚本Claim-relative表达范围内为SUPPORTED；AA-E02原缺口补齐后在机制范围内SUPPORTED；AA-E01仍INCONCLUSIVE。X5来源修复配置取得3/5完整真实路径及4/4效果边界，两次格式失败保留。原结果、范围和历史记录保留，不据局部机制升级生产质量；当前阶段处置见 Phase 6 证据评审。

Policy rationale 是可审计的语义说明，不是额外执行指令或学习者独立完成的证据。Executor 使用已校验 exact action payload 与当前 preconditions；Evaluation 使用原始作答、实际帮助及 Claim。理由仍须校验；其进入后续 reasoning 时，按该用途重新准入，不能以审计字段身份绕过职责或依据检查。E1/X5 未决的能力分期与重开条件见 Phase 6 ADR 002。

### 8.11 Reopen 条件

以下证据可能要求修订本专项，必要时重新打开上位 Architecture：

- 无法在不引入第二 learner state 的情况下表达真实 Interaction currentness；
- AI Policy 若不依赖大规模 hidden deterministic pedagogy rules 就无法保持可控；
- 在单会话串行之外，跨会话 / 外部变化仍必须依赖 learner-wide 全局锁才可保证 Decision Context correctness；
- ActionIntent / Executor 分离无法在真实 effect 系统中保持；
- Assistance exposure 无法由 ActionOccurrence lineage 重建，且必须引入独立 authoritative exposure state；
- `Execute / NoIntervention / Defer` 无法覆盖稳定真实 policy outcome，而需要新的不可约顶层结果；
- Plan 不携带未来 execution authority就无法实现现实长期任务；
- Context Authority 必须直接决定 learner-level action 才能运行；
- 真实场景持续证明 `Elicit / Expose / Control + disclosure / substitution` 无法表达关键 Action semantics。

普通实现 bug、性能问题或产品 UI 差异不构成 Architecture Reopen。

### 8.12 Roadmap Handoff

系统设计内部 Phase 6、Gate E/F 与后续 Build 已按原基线收口。本轮领域复核已传导至当前合同，现恢复 MVP Phase 3 的范围与验证条件评审，随后按 Roadmap 准备 Phase 4 资产并进入 Phase 5 工程。旧实验的否定与未决保持；新模型的具体资产、实现迁移与质量需按实际交付验证，见[当前系统设计入口](README.md)。

## Appendix A — Interaction & Decision Runtime Invariant Registry

| ID | Invariant |
|---|---|
| **IDR-01** | `DecisionTrigger != InterventionMandate`。 |
| **IDR-02** | `StateChange != DecisionMandate`。 |
| **IDR-03** | `Admissible != WorthDoing`。 |
| **IDR-04** | `InteractionPolicy cannot create LearnerBelief`。 |
| **IDR-05** | `ActionSemantics != ActionSelection`。 |
| **IDR-06** | `PolicyOutcome = Execute(ActionCandidate) | NoIntervention | Defer`。 |
| **IDR-07** | Runtime failure / Unauthorized / CandidateStale 不得伪装成 PolicyOutcome。 |
| **IDR-08** | `NoIntervention` 是一等正式 decision。 |
| **IDR-09** | `Defer != SuspendedActionCommand`。 |
| **IDR-10** | `TargetGap != EpistemicGap != Action`。 |
| **IDR-11** | `GoalIntent != LearningTarget != ExternalObligation != Plan`。 |
| **IDR-12** | `AuthorityDirective != PolicyBypass`。 |
| **IDR-13** | `AuthorityOverride != EpistemicEvidence`。 |
| **IDR-14** | `Plan != FutureCommandQueue`。 |
| **IDR-15** | 每个 future effect 必须经过新的 current decision / execution eligibility。 |
| **IDR-16** | `ActionCandidate != ActionIntent != ActionOccurrence`。 |
| **IDR-17** | Executor 不做 pedagogy judgment，不 silent substitute Action。 |
| **IDR-18** | `ExecutionPreconditionCheck != PolicyReexecution`。 |
| **IDR-19** | `SelectedAssistance != OccurredAssistance`。 |
| **IDR-20** | `OccurredAssistance != LearnerUsedAssistance`。 |
| **IDR-21** | `AssistanceOccurred != EvidenceContaminated`。 |
| **IDR-22** | `AssistanceContext != AuthoritativeExposureFact`。 |
| **IDR-23** | `InformationDisclosure != CognitiveWorkSubstitution`。 |
| **IDR-24** | `TaskTool != TargetSupport != RuntimeAvailability != OccurredToolUse`。 |
| **IDR-25** | `AIRuntimeToolUse != LearnerTaskToolUse`。 |
| **IDR-26** | `RuntimeLearnerCondition != LearnerBelief`。 |
| **IDR-27** | DecisionContext 是 exact snapshot，不是 Source of Truth。 |
| **IDR-28** | Pinned Decision meaning 不冻结 future authority / Data Authority。 |
| **IDR-29** | CandidateStale 时不得形成 ActionIntent。 |
| **IDR-30** | ActionIntent effect-time precondition 失败必须得到 NotOccurred，而不是改写 Action。 |
| **IDR-31** | `Rendered != Perceived != Understood != Used`。 |
| **IDR-32** | `PolicyRationale != Observation != Evidence != Belief`。 |
| **IDR-33** | `MoreEngagement not=> BetterPolicy`。 |
| **IDR-34** | Policy 必须保持合理 disconfirmation opportunity。 |
| **IDR-35** | Plan / Decision / Action history 不因后续版本变化而被重写。 |
| **IDR-36** | Governance Approval 不等于 learner-level execution command。 |

---

## Appendix B — Core Object Responsibility Matrix

| Object | Standing | Owner | Identity / Revision | Currentness | Authority | Key Dependencies | Historical Role |
|---|---|---|---|---|---|---|---|
| DecisionOpportunity | Runtime trigger record | Interaction / runtime coordinator | opportunity id | may expire / merge | no action authority | trigger refs | explains why decision was reconsidered |
| DecisionCycle | Runtime decision execution record | Interaction | cycle id | historical after completion | no independent future authority | opportunity + context + protocol | decision audit spine |
| DecisionContext | Snapshot | Interaction | context id | frozen historical snapshot | none | exact current inputs + version / authority basis | reconstruct decision inputs |
| AdmissibleActionEnvelope | Control projection | Interaction + authority/security inputs | execution-scoped | current-only | upper bound only | authority / support / tools / security | explains search space |
| PolicyCandidate | Candidate | Interaction semantic owner | candidate id | commit-sensitive | none until commit | DecisionContext | reasoning history |
| PolicyOutcome | Derived formal runtime decision | Interaction | outcome id / revision if applicable | historical decision standing | decision standing, not occurrence | DecisionContext + Policy protocol | what was decided |
| NoIntervention | PolicyOutcome | Interaction | outcome id | historical | none | decision basis | proves explicit non-action decision |
| Defer | PolicyOutcome | Interaction | outcome id | reevaluation condition | none | decision basis / future condition | explains why action was postponed |
| Plan | Derived formal runtime strategy | Interaction | plan id + revision | Active / Stale / Superseded / Abandoned / Completed | no future execution authority | Target / Binding / Belief / Authority | strategy history |
| RuntimeLearnerCondition | Runtime projection | Interaction | scoped state id / snapshot | short-lived / expiring | none | observation / event / time | current decision input only |
| ActionCandidate | Runtime decision candidate | Interaction | candidate id | commit-sensitive | none | PolicyOutcome basis | candidate history |
| ActionIntent | Runtime execution authority | Interaction / deterministic commit | intent id | short-lived / expiring | bounded effect authority | exact action + decision + current authority | execution authorization history |
| ActionOccurrence | Factual | Factual Runtime / authorized executor attestation | occurrence id | immutable | factual standing only | ActionIntent + effect attestation | authoritative occurred action |
| AssistanceContext | Runtime projection | Interaction | snapshot / projection | rebuildable | none | actual ActionOccurrence lineage | convenience view, not exposure SoT |
| Exposure Lineage | Provenance relation over factual action history | Interaction/Evaluation consume; factual refs authoritative | lineage refs | historical | none | ActionOccurrence / payload | evidence contamination basis |

---

## Appendix C — Canonical State / Outcome Transitions

### C.1 Decision Cycle

```text
Opportunity
→ ContextResolving
→ ContextReady
→ PolicyReasoning
→ CandidateReady
→ Revalidating
→ CommittedOutcome
    ├── Execute
    ├── NoIntervention
    └── Defer

Non-success terminals / retry paths:
ContextUnavailable
NoCurrentValidState
Unauthorized
DataAuthorityDenied
ModelFailure
ToolFailure
ProtocolFailure
CandidateStale
CommitConflict
VersionIncompatible
```

### C.2 Action Execution

```text
ActionCandidate
→ PostAdmissibility
→ ActionIntent
→ Dispatching
→ EffectCheck
→ Occurred
   | NotOccurred
   | Indeterminate
```

`Occurred` 之后才进入 Factual History。

### C.3 Plan

```text
Candidate
→ Active
→ Completed
 | Stale → Replan / Superseded
 | Abandoned
 | Expired
```

Plan 状态迁移不能直接执行 Action。

---

## Appendix D — Failure Semantics Matrix

| Situation | Correct Result | Forbidden Shortcut |
|---|---|---|
| Policy model timeout | ModelFailure | NoIntervention |
| DecisionContext CURRENT dep changed | CandidateStale | metadata-only rebase |
| Policy target head concurrently changed | CommitConflict | Last-Write-Wins |
| No current-valid Belief but required | NoCurrentValidState | use last known invalid belief |
| Authority revoked before outcome commit | Unauthorized / AuthorityStale | use snapshot permission |
| ActionIntent authority revoked before effect | NotOccurred | execute because previously approved |
| ActionIntent precondition changed | NotOccurred:PreconditionInvalidated | Executor reselects action |
| delivery result unknown | Indeterminate | assume Occurred / blindly retry |
| exposure lineage incomplete | ExposureUnknown | assume Independent |
| gap exists but action not worth cost | NoIntervention / possibly Defer | mandatory exercise / assessment |
| future condition reached after Defer | new DecisionOpportunity | execute old candidate |
| Plan target changed | Plan stale / replan | continue old queue |

---

## Appendix E — Pre-Validation Assumption Registry

| ID | Claim | Primary Invariant | Falsifier | Validation Dimension | Status | If Denied |
|---|---|---|---|---|---|---|
| AA-D01 | ActionOccurrence + occurred disclosure / payload + ordered lineage 足以重建 Assistance Exposure，无需独立 authoritative AssistanceExposureModel | IDR-19~23 | 关键 exposure 在真实运行中无法由 factual lineage 恢复，且需要新的 durable authoritative state | D | SUPPORTED（限定机制范围） | 修订 exposure representation；必要时重新评估是否需要独立 model |
| AA-D02 | Evaluation 可基于 claim-relative exposure lineage 判断 contamination，不需要 global assisted state | IDR-21~23 | 多数真实 claim 无法局部判断，只能依赖全局 assisted flag | D | SUPPORTED（限定机制范围） | 修订 Evidence / Assistance contract；必要时 reopen boundary |
| AA-E01 | AI 可承担真实 Policy judgment，deterministic layer 只控制 legality / authority / effect，不需要隐藏大量 pedagogy if/else | IDR-03~08,12,17 | 为保证质量/安全必须在 deterministic gate 编码大量实质 pedagogy 判断 | E | INCONCLUSIVE | 修订 Policy responsibility；若不可分离则 Architecture Reopen Candidate |
| AA-E02 | 单会话常规轮次严格串行；snapshot + revalidation 足以处理跨会话 / 外部变化，不需要 learner-wide 全局锁 | IDR-27~30 | 会话串行之外的变化持续导致无法阻止 stale effect，除非跨会话使用长事务 / 全局锁 | E | SUPPORTED（原缺口已补证） | 修订 consistency boundary / conflict model；必要时 reopen concurrency design |

---

## Appendix F — Focused Design Closure Checklist

| Roadmap §3.5 要求 | v0.1 覆盖位置 | 状态 |
|---|---|---|
| Decision Context composition | §3.3–3.4 | CLOSED / Pre-Validation |
| Policy reasoning protocol | §3.6、§4 | CLOSED / Pre-Validation |
| Trigger vs mandate | §2.2、§4.7 | CLOSED |
| admissible action space | §3.5、§4.2 | CLOSED / Pre-Validation |
| ActionCandidate / NoIntervention / Defer | §3.7–3.10 | CLOSED |
| deterministic admissibility gate | §3.5、§5.2–5.3 | CLOSED / Pre-Validation |
| ActionIntent / Executor / ActionOccurrence | §3.13–3.14、§5.5–5.7 | CLOSED / Pre-Validation |
| plan / replanning / multi-timescale decision | §3.11、§4.12、§6.6–6.7 | CLOSED |
| runtime learner condition | §3.12、§6.8 | CLOSED |
| Assistance Exposure Lineage | §3.15–3.16、§6.1–6.3 | CLOSED / 有界机制证据；语义或组合结论仍受限制 |
| Tool / Support / Availability / Occurred Use | §3.17、§6.4–6.5 | CLOSED |
| Active Assessment ownership | §4.8 | CLOSED |
| concurrent stale → re-decision | §5.3–5.5、§7.4–7.5 | CLOSED / 有界机制证据；语义或组合结论仍受限制 |
| authority does not bypass Policy | §2.5、§4.11、§8.8 | CLOSED |
| failure / recovery / audit | §7，含 §7.13 尝试失败与轮次终止的区分 | 合同已明确；远程停止、迟到效果对账及崩溃恢复仍待验证 |
