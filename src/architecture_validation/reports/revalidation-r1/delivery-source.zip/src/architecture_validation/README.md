# DeerMind Architecture Validation Build

这是 Development Phase 2 的单进程参考实现。它运行 Event → Observation → Evidence → Belief → Policy → 受控浏览器展示确认，并保存来源、精确引用、候选、语义校验、owner 提交、失效依赖及恢复记录。真实生成和审查使用 DeepSeek；`scripted` 模式只用于工程机制检查，不证明模型能力。

当前有界修复 R1 已结束，G2 仍为 HOLD。最后开发轮完成4/6轮，没有完整三轮会话；真实提示后的评价及决策已有开发证据，完整讲解和其余正式对照未通过准入。正式复验没有启动。当前结果以 [Build Validation Report v0.2](../../doc/system-design/build/DeerMind_Architecture_Validation_Build_Validation_Report_v0.2.md) 为准，不能把未执行的正式样本记为失败或成功。

## 安装与本地运行

在仓库根目录使用 PowerShell：

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r src/architecture_validation/requirements.lock.txt
.venv\Scripts\python.exe -m playwright install chromium
$env:PYTHONPATH = 'src'
.venv\Scripts\python.exe -m architecture_validation.server --model scripted --db src/architecture_validation/runs/demo/runtime.sqlite --run-dir src/architecture_validation/runs/demo --port 8765
```

服务只监听 `127.0.0.1`。在另一个 PowerShell 窗口读取本机控制文件、建立题目并打开页面：

```powershell
$control = Get-Content src/architecture_validation/runs/demo/server.control.json -Raw | ConvertFrom-Json
$adminHeaders = @{ Authorization = 'Bearer ' + $control.admin_token }
$taskBody = @{ id='demo'; quantity=6; total=42; target=15; noun='练习本' } | ConvertTo-Json
$task = Invoke-RestMethod http://127.0.0.1:8765/admin/tasks -Method Post -Headers $adminHeaders -ContentType 'application/json; charset=utf-8' -Body ([System.Text.Encoding]::UTF8.GetBytes($taskBody))
$learnerUrl = 'http://127.0.0.1:8765/#session=demo&task=' + [uri]::EscapeDataString($task.id) + '&token=' + [uri]::EscapeDataString($control.learner_token)
Start-Process $learnerUrl
```

开发题为“6份练习本42元，15份多少钱”。输入计算或请求后，页面纯文本渲染已获准内容，确认块标识、顺序、payload hash 和通道代次。确认仅代表受控客户端完成渲染，不代表学习者看见、理解或使用。中断按钮会先停止处理，再执行受控通道停止和对账。`server.control.json` 包含本机测试凭据，不应进入 Git；API key 不写入该文件。

真实模式读取仓库 `.env` 或环境变量中的 `DEERMIND_LLM_API_KEY`、`DEERMIND_LLM_BASE_URL`、`DEERMIND_LLM_MODEL`。本次已执行的实验预算账本不能删除或清零后冒充同一次测量。`--model real --phase B2` 与 `measure` 会受持久化调用、token、费用和时间上限约束。新的真实批次应另定实验版本与预算，不能直接重复已完成保留样本并合并成绩。

R1的独立账本、源码冻结、原始结果、评分和准入决定在 `reports/revalidation-r1/`。`revalidate dev1` 和 `dev2` 已执行，运行器拒绝覆盖；`revalidate formal` 因 `admission.json` 为 false 而拒绝发起。不要删除目录或改写准入标记来绕过停止条件。复核 R1 不需要 API key，可直接阅读 `assessment.json`、`quality-review.json` 和 `integrity.json`。

## 验证和证据

```powershell
$env:PYTHONPATH = 'src'
.venv\Scripts\python.exe -m pytest src/architecture_validation/tests -q
```

该命令不调用付费模型。24 条机制路径在 `test_mechanisms.py` 中；补充检查覆盖 schema、实际浏览器、精确 ID 映射、输入容量及中断后 worker 迟返。重启测试实际结束并重新启动服务进程。10、100、1000 节点测量是合成依赖图的事务与固定内容重建成本；真实 owner 重算由更正和规范激活路径单独验证。

`fixtures/holdout-v1.json` 保存六段会话、允许分支及四项 Evaluation 对照；`fixtures/probes-v1.json` 保存12个评审探针。测试期望不进入运行时生成上下文。`reports/` 保存冻结清单、来源快照、检查记录、调用账本和阶段结论；`runs/` 保存可重新生成的运行数据库、HTTP 模型记录、浏览器证据和本机控制文件。最终证据包排除密钥及本机控制凭据。

官方离线分词器及其来源 hash 保存在 `fixtures/`。本地估算加25%余量和512个封装 tokens；实际计量以供应商返回 usage 为准。费用保守采用核验时官方高峰、未命中缓存价格，具体依据见 `fixtures/pricing-v1.json`。请求材料超过本地输入预算时明确失败，不静默截断。

当前本地准入为32K估算tokens及200K封装字符；R1最高估算12,421，没有容量阻断。模型仅能选择当前Context列出的短ID，后端绑定精确引用；短编号在同一数据库保持稳定，历史来源不会随下一轮编号排列变化而误指。

## 实现边界

SQLite 是唯一持久化权威，日志不是恢复正式状态的替代品。记录追加后不可改写，head、有效性与队列是事务维护的投影。规范提交和激活分别记账，撤权及版本变化在提交、派发前检查；规范回退形成新的激活事实。有权管理者可以通过 `/admin/recompute` 请求基于原始 Event 的 owner 重算，不伪造新的学习者作答。

同一会话严格串行，本原型也只使用一个全局 worker。多进程部署、跨机恢复、多租户权限和生产级认证不在本次范围内。LLM 负责意义判断，程序只检查结构、精确身份、权限、时序、依赖和实际提交/展示。语义审查仍可能误放和误拒；审核 PASS 不构成语义正确的证明。

阶段结果以 `doc/system-design/build/` 下的统一 Build Validation Report 为准；方案中的通过门槛和既有 Spike 否定结论不会因参考实现存在而自动满足。
