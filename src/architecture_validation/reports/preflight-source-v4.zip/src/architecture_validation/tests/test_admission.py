from architecture_validation.common import BASE,Rejected,dumps
from architecture_validation.model import RealModel
from architecture_validation.store import Store
from architecture_validation.runtime import Engine
from architecture_validation.testing import ScriptedModel
from architecture_validation.domain import task


def test_token_estimate_four_turns_without_api(tmp_path):
    import math
    st=Store(tmp_path/'capacity.sqlite');st.bootstrap();q=st.canonical(task('capacity',6,42,15,'本'));st.start_session('s')
    # Construct official tokenizer without loading credentials or any transport.
    from tokenizers import Tokenizer
    tokenizer=Tokenizer.from_file(str(BASE/'fixtures/deepseek-v4-tokenizer.json'))
    model=ScriptedModel();original=model.complete;bounds=[]
    def measure(system,ctx,schema,purpose,category='base'):
        texts=[system+'\n输出 JSON schema：'+dumps(schema),dumps(ctx)]
        bounds.append(math.ceil(sum(len(tokenizer.encode(v,add_special_tokens=False).ids) for v in texts)*1.25)+512)
        return original(system,ctx,schema,purpose,category)
    model.complete=measure;engine=Engine(st,model,test_mode=True)
    for n in range(4):
        t=st.enqueue('s',str(n),'42÷6＝7，7×15＝105。',q);st.claim_turn(engine.worker_epoch);engine.process(t['id'])
        assert st.turn(t['id'])['status']=='COMPLETED'
    assert len(bounds)==32 and max(bounds)<16000
