# 逐项语义校验 v2 定向回归复核

日期：2026-09-30。模型：`deepseek-flash`。Protocol 为 `ObservationSmokeProtocol:v2`，语义规则为 `ObservationRules:v2`。固定两个候选，每个进行一次独立校验，共 2 次调用，无重试；供应商报告合计 2572 tokens（输入 1974，输出 598）。

| 候选 | 模型逐项判断 | 提交结果 | 复核 |
|---|---|---|---|
| 原始漏项候选 | method / division / grounding / boundary 为 PASS，final_result 为 FAIL | ValidationFailed | 校验理由明确指出候选没有判断最终总价 120 错误，与原文一致 |
| 最小补齐正例 | 五项均为 PASS | Committed | final_result 引用的是正例实际新增的句子，明确指出 120 错误及正确总价 105 |

程序已核验所有引用均为 exact candidate 指定字段的原文子串；本次开发会话的助手另复核了两份完整候选、逐项引用与校验理由。原始负例被拒、修复正例被接受，满足运行前声明的配对期望；未把拒绝全部候选当作成功。

本轮保留 v1 原始误放批次，未修改历史 PASS 或已提交状态。v2 使用新的 Protocol / rule revision，生成提示保持与 v1 相同。候选来自固定回归材料，本轮没有重新运行生成，因此没有证明生成漏项本身已解决。

本轮只能支持“新版在这组已知正反例上区分正确”。引用存在性检查不判断语义蕴含；即便引用真实存在，LLM 仍可能误解其支持关系。该样例参与了校验规则改进，属于回归验证，不是独立泛化测试或可靠率估计。完整 A1 / A2 的重复运行、未见表达、混合越界内容与误拒检查仍待执行，Architecture Assumptions 保持 UNVALIDATED，Gate E / F 保持 OPEN。
