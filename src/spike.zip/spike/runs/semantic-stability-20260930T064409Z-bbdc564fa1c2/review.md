# Observation v2 新样例重复验证审查

审查日期：2026-09-30。审查者：Codex，根据实际请求、原始模型响应和提交记录复核。

## 结论

本批结果为 **NON_SUCCESS**。40 次真实校验中，35 次符合预先声明的预期，5 次误放，0 次误拒。5 次误放全部来自 `fabricated_attribution_negative`，并且全部已在隔离的 Spike 运行中提交为 Observation。当前 v2 方案未能可靠区分有来源的学习者自述与候选虚构的自述。

这是真实语义校验失败，不是传输错误、缺失调用或实验装配错误。后续修改不能覆盖或抵消本批反例。

## 冻结条件与结果

- 模型：`deepseek-flash`；temperature 0；thinking disabled；每次最多 1024 输出 tokens；无重试。
- 8 个开发者编写的新样例，每个重复 5 次，共 40 次独立请求。样例及预期在调用前固定；每轮按固定 seed 20260930 排序。
- 协议 SHA-256：`9963a25efdd57c32dc1aa8786ee6988fcee68e89c3169c23dbd0fbb8465fc608`。
- 样例文件 SHA-256：`0a19857d19016f1189b19953fa293def0338192c148c454db728ab4e1e514c71`。
- 完成后复核 `manifest.json` 中全部文件哈希，无变化。批次中未根据中间结果修改规则、样例或实现。
- 40 次调用全部完成；无 UNRESOLVED、协议错误或运行错误。消耗输入 37885、输出 12233，合计 50118 tokens。
- 原 `.env` 的默认 2 次调用上限未改动；本次显式设置批次上限 40。

| 样例 | 预期 | 实际结果 | 提交结果 |
| --- | --- | --- | --- |
| 英文同义表达 | PASS | 5 PASS | 5 Committed |
| 中文表达 | PASS | 5 PASS | 5 Committed |
| 有来源的学习者自述 | PASS | 5 PASS | 5 Committed |
| 缺少最终答案判断 | FAIL | 5 FAIL | 5 ValidationFailed |
| 越界推断潜在能力 | FAIL | 5 FAIL | 5 ValidationFailed |
| 越界提出教学行动 | FAIL | 5 FAIL | 5 ValidationFailed |
| 附加错误算术断言 | FAIL | 5 FAIL | 5 ValidationFailed |
| 虚构学习者自述来源 | FAIL | **5 PASS** | **5 Committed** |

因此合法样例 15/15 正确放行，非法样例 20/25 正确拦截。每个样例的五次判定签名均一致，包括错误判定。上述计数不代表真实用户分布上的错误率；这些样例也不是第三方盲测数据。

## 反例与实际请求复核

正负例的候选内容完全相同，都在正确的局部算术观察之后添加：

> The learner wrote, "I cannot do division; please explain it." This is a report of the learner's own statement and request, not an independently established ability judgment.

正例的 `work:1` 原始文本确实包含这句话。负例的同一来源字段只有：

> 42 / 6 = 8; 8 * 15 = 120; Answer = 120

复核了实际发送给服务商的请求，而不只是 fixture。负例请求的 context 没有上述自述，模型可见的候选却声称学习者说过。各次请求使用独立上下文，没有携带前一次对话历史。

负例五次 `grounding` 均为 PASS，第一次的理由为：

> All assertions match the task, the submitted work, and the correct arithmetic, with the learner quotation explicitly attributed.

五次全部五项 criterion 为 PASS，随后确定性提交门按该结果提交候选。运行链路执行符合现有规则，但错误事实仍然取得了正式 Observation 地位。

## 原因判断与适用范围

从可见输出推断，校验模型把“陈述采用了归属形式”混同为“归属有原始来源支持”。这是根据响应作出的机制推断，不是对模型内部过程的观察。

v2 的摘录检查验证的是引文是否存在于候选，不能证明候选中的引语实际出现在学习者来源中；whole_candidate 的 PASS 又允许空摘录。规则虽然要求所有断言有来源支持，但目前没有逐项展示候选断言与来源证据的对应关系。

有来源的自述与虚构自述需要得到不同结论。不能通过禁止“不会除法”等词来修复，否则会误拒合法自述。重复调用本身也没有在本批纠正错误。

本批已否定“当前 v2 能正确区分这组有来源／无来源自述”的具体命题。`summary.json` 中整体 AA 的 UNVALIDATED 表示完整 A1/A2 尚未执行完毕，并不表示本批没有失败。正式 A2 审查必须纳入这五次误放，按声明的假设与反证条件判断；不得仅以未来修复为由撤销反例，也不得据此宣称整个架构已得到支持。

## 下一步设计建议

为需要来源支持的候选断言建立“候选片段 → 精确来源 ref、字段、片段”的可检查对应，并区分直接引语、转述、局部推导。确定性逻辑检查引用存在、版本及直接引语匹配；明确的语义规则与 LLM 判断来源是否支持该断言及其归属。找不到足够支持时应 FAIL 或 UNRESOLVED，阻止提交。

后续应另建协议版本及运行目录，保留此反例作为回归样例，并加入未参与修订的新样例。本次没有修改 v2 或追加模型调用。

## 证据

- `manifest.json`：运行前冻结的文件哈希、模型参数、全部样例及预期。
- `evidence.jsonl`：40 组候选、语义校验、提交、真实请求／响应和快照。
- `summary.json`：完整逐次结果及统计。
- 本轮本地自动化测试 64 项通过；这只证明对应实现检查通过，不能替代上述真实语义失败结论。`git diff --check` 通过。
