"""Check declared mechanical contracts before a bounded model campaign."""
from .structured_output import check_schema
from .expressions import FORMAT, extraction_contract


def check_observation_contract(definition):
    contracts=definition['output_contracts']
    for contract in contracts.values():
        check_schema(contract['parameters'])
    schema=contracts['generation']['parameters']
    if set(schema['properties'])!={'description'} or schema['properties']['description']['type']!='string':
        raise ValueError('ObservationGenerationFieldsMismatch')
    criteria=[c['id'] for c in definition['criteria']]
    declared=contracts['validation']['parameters']['properties']['criteria']['items']['properties']['id']['enum']
    if len(criteria)!=len(set(criteria)) or len(declared)!=len(set(declared)) or set(criteria)!=set(declared):
        raise ValueError('CriterionSchemaMismatch')
    admitted=set(definition['responsibility_admission'])
    roles=contracts['responsibility']['parameters']['properties']['segments']['items']['properties']['role']['enum']
    if admitted!=set(roles):raise ValueError('ResponsibilityRoleSchemaMismatch')
    profile=definition.get('arithmetic_extraction_format')
    if profile is not None:
        if profile!=FORMAT:raise ValueError('UnsupportedArithmeticExtractionFormat')
        if definition['validation_format']!='arithmetic-linked-v6' or 'arithmetic_mapping' not in criteria:
            raise ValueError('RequiredArithmeticMappingReviewMissing')
        fields=list(schema['properties'])
        if contracts['extraction']!=extraction_contract(fields):raise ValueError('ExpressionContractMismatch')
        validation=contracts['validation']['parameters']['properties']
        exact={'type':'string','enum':fields}
        field_schemas=[validation['reviewed_fields']['items'],
            validation['criteria']['items']['properties']['quotes']['items']['properties']['field'],
            validation['claims']['items']['properties']['field'],
            contracts['responsibility']['parameters']['properties']['segments']['items']['properties']['field']]
        if any(s!=exact for s in field_schemas):raise ValueError('ExactCandidateFieldSchemaMismatch')
    return {'status':'PASS','criteria':criteria,'responsibility_roles':roles,'schemas_checked':len(contracts)}
