<script setup lang="ts">
import { computed } from 'vue';
import { state as stateSource, catalog, resolve, scopeBindings, createRevision, newDefinition, importDefinitionPackage, act, objectActivity, domain } from '../workbench/store';
const state=stateSource;
import { kinds, editableKinds, personalKinds, objectKey, type Kind } from '../workbench/model';
import { route as routeSource, go, setQuery, openObject, back } from '../workbench/navigation';
const route=routeSource;
import ModelObjectContent from './ModelObjectContent.vue';
import AccessGate from './AccessGate.vue';
const selectedDomain=computed(()=>route.page==='domain'?domain(route.domain):undefined);
const location=window.location;
const title=computed(()=>route.page==='domain'?selectedDomain.value?.name||'领域管理':route.page==='evaluation'?'评估模型管理':route.page==='object'?'对象详情':'空间观测');
const spaceKinds:Record<string,string[]>={Domain:['task','solution','kc'],Evaluation:['claim','evidence-rule','inference-rule','evidence','belief','assessment'],Interaction:['observation','policy','action'],Learning:['material','chapter','mapping','target'],Evolution:[]};
const typeOptions=computed(()=>route.page==='domain'?['task','solution','kc']:route.page==='evaluation'?['claim','evidence-rule','inference-rule']:spaceKinds[route.tab||'Domain']||[]);
const activeKind=computed(()=>typeOptions.value.includes(route.filter)?route.filter:typeOptions.value[0]||'task');
const rows=computed(()=>catalog().filter(o=>(route.page!=='objects'||o.space===space.value) && (route.page!=='domain'||o.domainId===route.domain) && o.kind===activeKind.value && (!route.q||`${o.id} ${o.name} ${o.summary}`.toLowerCase().includes(route.q.toLowerCase()))));
const pending=computed(()=>state.issues.filter(i=>!i.published && i.candidate?.domainId===route.domain && i.candidate.kind===activeKind.value));
const paged=computed(()=>rows.value.slice((route.p-1)*10,route.p*10));
const obj=computed(()=>resolve(route.id,route.scope?scopeBindings(route.scope):undefined));
const guarded=computed(()=>obj.value && personalKinds.includes(obj.value.kind));
const accessRef=computed(()=>objectActivity(route.id)?.id || (obj.value?objectActivity(objectKey(obj.value))?.id:undefined) || route.id);
const space=computed(()=>route.tab||'Domain');
const descriptions:Record<string,string>={Domain:'定义任务、求解方法和知识，不保存个人掌握状态。',Evaluation:'Learner State / Evidence / Inference：分别定义评什么、如何解释表现、如何综合判断。',Interaction:'Observation / Policy / Action：区分输入理解、决策与实际发生的帮助。',Learning:'教材、目标与空间采用；课程范围不会裁剪共享 Domain 定义。',Evolution:'问题、候选、检查与受控修订；通过维护与发布工作区操作。'};
function selectSpace(value:string){setQuery({tab:value,filter:({Domain:'task',Evaluation:'claim',Interaction:'observation',Learning:'material',Evolution:'task'} as Record<string,string>)[value]!,q:'',p:1});}
async function importPackage(event:Event){const input=event.target as HTMLInputElement;const file=input.files?.[0];if(!file)return;try{if(file.size>100000)throw Error('版本包过大，请拆分为单对象交付。');const data=JSON.parse(await file.text());act(()=>go('maintenance',{id:importDefinitionPackage(data),tab:'candidate'}));}catch(e){act(()=>{throw e;});}finally{input.value='';}}
function exportPackage(){if(!obj.value)return;const next={...JSON.parse(JSON.stringify(obj.value)),version:obj.value.version+1,status:'draft'};const url=URL.createObjectURL(new Blob([JSON.stringify({format:'deermind-definition-package-v1',object:next},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=next.id+'-candidate.json';a.click();URL.revokeObjectURL(url);}
</script>
<template><div class="wb-page">
  <header class="page-header"><div><button v-if="route.page==='object'" class="text-link" @click="back('objects')">← 返回来源</button><button v-if="route.page==='domain'" class="text-link" @click="back('domain')">← 返回领域列表</button><h2>{{title}}</h2><p class="page-desc">{{selectedDomain?selectedDomain.scope:route.page==='object'?'同一身份、准确版本；各入口共享定义和维护流程。':'可查询的模型目录；个人状态与规范定义分开查看。'}}</p><details v-if="selectedDomain" class="domain-description"><summary>领域说明</summary><p>{{selectedDomain.description||'尚未填写补充说明。'}}</p><small class="mono">{{selectedDomain.id}}</small></details></div>
    <button v-if="route.page==='domain' && selectedDomain && ['task','solution','kc'].includes(activeKind)" class="btn primary" @click="act(()=>go('maintenance',{id:newDefinition(activeKind as 'task'|'solution'|'kc',route.domain),tab:'candidate',returnTo:location.hash}))">新增{{kinds[activeKind as Kind]}}</button>
    <button v-if="obj && route.page==='object' && editableKinds.includes(obj.kind)" class="btn primary" @click="act(()=>go('maintenance',{id:createRevision(route.id),tab:'candidate'}))">创建修订</button>
  </header>
  <div v-if="route.page==='evaluation' || (route.page==='object' && obj && ['claim','evidence-rule','inference-rule'].includes(obj.kind))" class="panel"><div class="row-between"><p>版本包只形成候选，仍需案例检查、审核、发布和指定采用。</p><button v-if="obj" class="btn" @click="exportPackage">导出候选版本包模板</button></div><label>导入语义定义版本包<input type="file" accept=".json,application/json" @change="importPackage"/></label></div>
  <template v-if="route.page==='object'">
    <div class="tabs"><button v-for="(label,key) in {definition:'定义内容',relations:'关联关系',versions:'版本记录',impact:'使用与影响'}" :key="key" :class="{active:(route.tab||'definition')===key}" @click="setQuery({tab:key})">{{label}}</button></div>
    <section class="panel"><AccessGate v-if="guarded" :subject="accessRef"><ModelObjectContent :reference="route.id" :scope="route.scope" :tab="route.tab||'definition'"/></AccessGate><ModelObjectContent v-else :reference="route.id" :scope="route.scope" :tab="route.tab||'definition'"/></section>
  </template>
  <template v-else>
    <template v-if="route.page==='objects'"><div class="tabs"><button v-for="s in Object.keys(descriptions)" :key="s" :class="{active:space===s}" @click="selectSpace(s)">{{s==='Learning'?'Learning Space':s+' Space'}}</button></div><p class="callout">{{descriptions[space]}}</p><button v-if="space==='Evolution'" class="btn primary" @click="go('maintenance')">查看维护事项与发布记录</button></template>
    <p v-if="route.page==='evaluation'" class="callout">Task Claim 内包含多个评价方面；同一模板、同一组评价条件组织一个多维 Claim。规则采用受控版本交付，本轮不增加通用在线编辑器。</p>
    <div class="toolbar"><label class="search-label">搜索<input :value="route.q" @input="setQuery({q:($event.target as HTMLInputElement).value,p:1})" placeholder="名称、编号或定义内容"/></label><label>对象类型<select aria-label="对象类型" :value="activeKind" @change="setQuery({filter:($event.target as HTMLSelectElement).value,p:1})"><option v-for="k in typeOptions" :key="k" :value="k">{{kinds[k as Kind]}}</option></select></label><span class="muted">{{rows.length}} 项 · 精确数量</span></div>
    <section class="table-card"><table class="data-table"><thead><tr><th>对象</th><th>所属模型</th><th>定义或含义</th><th>版本与状态</th><th>操作</th></tr></thead><tbody><tr v-for="o in paged" :key="objectKey(o)"><td><button class="text-link" @click="openObject(objectKey(o))">{{o.name}}</button><small class="mono">{{o.id}}</small></td><td>{{o.space}}<small>{{o.model}}</small></td><td>{{o.summary}}</td><td>v{{o.version}}<small>{{o.status==='published'?'已发布':o.status==='recorded'?'历史记录':'草稿'}}</small></td><td><button class="btn" @click="openObject(objectKey(o))">详情</button></td></tr></tbody></table><div v-if="!rows.length" class="empty">{{selectedDomain&&!route.q?'本领域还没有已发布的'+kinds[activeKind as Kind]+'。可从右上方新增，保存候选后继续检查与发布。':'没有符合筛选条件的对象。'}}</div></section>
    <section v-if="selectedDomain && pending.length" class="panel"><h3>未发布候选（{{pending.length}}）</h3><div v-for="i in pending.slice(0,10)" :key="i.id" class="list-row"><button class="text-link" @click="go('maintenance',{id:i.id,tab:'candidate',returnTo:location.hash})">{{i.candidate?.name||'未命名'+kinds[activeKind as Kind]}}</button><span class="muted">{{i.id}}</span></div><button v-if="pending.length>10" class="text-link" @click="go('maintenance',{domain:route.domain,filter:'pending'})">查看本领域全部维护事项</button></section>
    <div class="pagination"><button class="btn" :disabled="route.p<=1" @click="setQuery({p:route.p-1})">上一页</button><span>第 {{route.p}} / {{Math.max(1,Math.ceil(rows.length/10))}} 页</span><button class="btn" :disabled="route.p*10>=rows.length" @click="setQuery({p:route.p+1})">下一页</button></div>
    <p v-if="state.objects.length" class="muted">当前为可操作的统一示例目录，未将示例定义接入真实学生对话。</p>
  </template>
</div></template>
