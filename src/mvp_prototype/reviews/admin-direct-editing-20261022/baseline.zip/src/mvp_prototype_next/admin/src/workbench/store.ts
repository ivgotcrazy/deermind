import { reactive, ref, toRaw } from 'vue';
import { seed } from './seed';
import { migrateDomains } from './migration';
import { editableKinds, personalKinds, objectKey, type AdminState, type ModelObject, type Issue, type Check } from './model';
export const STORAGE_KEY = 'deermind-next-admin-workbench-v1';
export const storageError = ref('');
export const clone = <T>(x:T):T => JSON.parse(JSON.stringify(x));
let initial = seed();
try {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    const data = JSON.parse(saved);
    if(![1,2].includes(data.schema) || !Array.isArray(data.objects) || !data.invalidated || !Array.isArray(data.issues)) throw Error();
    if(data.schema===1) {
      if(!localStorage.getItem(STORAGE_KEY+'.before-domains')) localStorage.setItem(STORAGE_KEY+'.before-domains',saved);
      initial=migrateDomains(data);
    } else {
      if(!Array.isArray(data.domains) || data.domains.some((d:unknown)=>!d || typeof (d as {id?:unknown}).id!=='string')) throw Error();
      initial=data;
    }
  }
} catch { storageError.value='本地工作记录无法读取，原记录未覆盖。请先导出浏览器中的原始记录，再检查恢复；当前只读显示初始示例。'; }
export const state = reactive<AdminState>(initial);
export const notice = ref('');
export const mode = ref<'demo'|'real'>('demo');
export function transact(fn:(s:AdminState)=>void) {
  if(storageError.value) throw Error(storageError.value);
  const saved = localStorage.getItem(STORAGE_KEY);
  if(saved && JSON.parse(saved).revision !== state.revision) throw Error('另一窗口已更新工作记录。请刷新本页后再操作，避免覆盖。');
  const next = clone(toRaw(state)); fn(next); next.revision++;
  try { localStorage.setItem(STORAGE_KEY,JSON.stringify(next)); } catch { throw Error('浏览器保存失败，本次操作未提交。请导出已有记录并检查存储空间。'); }
  Object.assign(state,next);
}
export function act(fn:()=>void) { notice.value=''; try { fn(); } catch(e) { notice.value=e instanceof Error?e.message:String(e); } }
export function latest(id:string, s:AdminState=state):ModelObject|undefined { return s.objects.filter(o=>o.id===id).sort((a,b)=>b.version-a.version)[0]; }
export function resolve(ref:string, bindings?:Record<string,number>, s:AdminState=state):ModelObject|undefined {
  const [id,version] = ref.split('@');
  const exact = version ? Number(version) : bindings?.[id!];
  return exact!==undefined ? s.objects.find(o=>o.id===id && o.version===exact) : bindings ? undefined : latest(id!,s);
}
export function catalog(s:AdminState=state) { return s.objects.filter(o=>latest(o.id,s)?.version===o.version); }
export function domain(id:string,s:AdminState=state) { return s.domains.find(d=>d.id===id); }
export function createDomain(name:string,scope:string,description:string) {
  const values={name:name.trim(),scope:scope.trim(),description:description.trim()};
  if(!values.name || !values.scope) throw Error('请填写领域名称和覆盖范围。');
  if(values.name.length>80 || values.scope.length>1000 || values.description.length>2000) throw Error('名称最多 80 字，覆盖范围最多 1000 字，说明最多 2000 字。');
  const id='DOM-'+crypto.randomUUID().toUpperCase();
  transact(s=>{
    const normalized=(v:string)=>v.normalize('NFKC').toLocaleLowerCase();
    if(s.domains.some(d=>normalized(d.name)===normalized(values.name))) throw Error('已有同名领域，请使用可区分的名称。');
    s.domains.unshift({id,...values,createdAt:new Date().toISOString()});
  });
  return id;
}
export function dependents(id:string,s:AdminState=state) { return catalog(s).filter(o=>o.relations.some(r=>r.ref.split('@')[0]===id)); }
export function scopeBindings(scope:string) { return state.spaces.find(s=>s.id===scope)?.adopted || state.activities.find(a=>a.id===scope)?.versions; }
export function objectActivity(key:string) { return state.activities.find(a=>a.objects.includes(key)); }
export function canAccess(ref:string, dataMode='demo') { return state.access.some(a=>a.ref===ref && a.mode===dataMode); }
export function recordAccess(ref:string,purpose:string,dataMode='demo') {
  if(!purpose.trim()) throw Error('请填写本次查看用途。');
  transact(s=>s.access.push({at:new Date().toISOString(),ref,purpose:purpose.trim(),mode:dataMode}));
}
export function makeIssue(title:string,origin:string,purpose:string,dataMode:'demo'|'real'='demo') {
  if(!title.trim() || !purpose.trim()) throw Error('请说明事项名称和核对目的。');
  const id='REV-'+crypto.randomUUID().slice(0,8).toUpperCase();
  transact(s=>s.issues.unshift({id,title:title.trim(),origin,purpose:purpose.trim(),finding:'',conclusion:'',verdict:'open',sampleCases:[],impacts:[],log:[{at:new Date().toISOString(),text:'建立事项；尚未判断问题成立。'}],dataMode}));
  return id;
}
export function issue(id:string) { const found=state.issues.find(i=>i.id===id); if(!found) throw Error('维护事项不存在。'); return found; }
export function mutateIssue(id:string,fn:(i:Issue,s:AdminState)=>void) { transact(s=>{const i=s.issues.find(i=>i.id===id); if(!i) throw Error('维护事项不存在。'); fn(i,s);}); }
export function log(i:Issue,text:string) { i.log.push({at:new Date().toISOString(),text}); }
export function createRevision(ref:string,origin=ref,purpose='核对定义与实际使用条件') {
  const current=resolve(ref); if(!current || !editableKinds.includes(current.kind)) throw Error('此对象只支持查看及受控版本交付，不能在这里直接编辑。');
  const id=makeIssue(`修订：${current.name}`,origin,purpose);
  mutateIssue(id,i=>{i.candidate=clone(current);i.candidate.version=(latest(current.id)?.version||0)+1;i.candidate.status='draft';i.baseVersion=current.version;log(i,`以 ${objectKey(current)} 为基线准备候选；尚未检查。`);});
  return id;
}
export function attachRevision(id:string,ref:string) {
  const o=resolve(ref);if(!o||!editableKinds.includes(o.kind))throw Error('请选择可维护的领域、教材或目标定义。');
  mutateIssue(id,i=>{if(i.dataMode!=='demo'||i.published)throw Error('不能在此事项中建立示例模型候选。');if(i.candidate)throw Error('本事项已有候选，请先完成或另建事项。');i.candidate=clone(o);i.candidate.version=latest(o.id)!.version+1;i.candidate.status='draft';i.baseVersion=o.version;i.sampleCases=state.activities.some(a=>a.id===i.origin)?[i.origin]:[];log(i,`关联 ${objectKey(o)} 的修订候选；原复核依据保留。`);});
}
export function importDefinitionPackage(value:unknown,existingIssue?:string) {
  const data=value as {format?:string;object?:ModelObject};
  const incoming=data?.object;
  if(data?.format!=='deermind-definition-package-v1'||!incoming||!['claim','evidence-rule','inference-rule'].includes(incoming.kind))throw Error('需要合法的 Claim、证据规则或推断规则版本包。');
  const base=latest(incoming.id);
  if(!base||base.kind!==incoming.kind||incoming.version!==base.version+1)throw Error('版本包必须对应已有对象，并在当前版本基础上递增一次。');
  if(typeof incoming.name!=='string'||typeof incoming.summary!=='string'||!incoming.fields||Array.isArray(incoming.fields)||!Object.values(incoming.fields).every(v=>typeof v==='string')||!Array.isArray(incoming.relations)||!incoming.relations.every(r=>typeof r.label==='string'&&typeof r.ref==='string'))throw Error('版本包定义字段或引用结构不完整。');
  if(incoming.kind==='claim'&&(!Array.isArray(incoming.aspects)||!incoming.aspects.length||!incoming.aspects.every(a=>typeof a.key==='string'&&typeof a.label==='string'&&typeof a.criterion==='string'&&typeof a.evidence==='string'&&typeof a.applicable==='boolean'&&(a.applicable||!!a.reason))))throw Error('Claim 方面须有稳定键、条件、证据要求及不适用依据。');
  const candidate:ModelObject={...clone(base),version:incoming.version,name:incoming.name,summary:incoming.summary,fields:clone(incoming.fields),relations:clone(incoming.relations),...(incoming.kind==='claim'?{aspects:clone(incoming.aspects)}:{}),status:'draft',source:'管理员导入的版本包；待检查和审核'};
  const id=existingIssue||makeIssue('受控版本交付：'+base.name,objectKey(base),'核对语义规则版本包、固定事实案例及影响');
  mutateIssue(id,i=>{if(i.candidate||i.published||i.dataMode!=='demo')throw Error('此事项不能再接入一个规则候选。');i.candidate=candidate;i.baseVersion=base.version;i.delivery=true;log(i,'导入版本包，未直接生效；候选正文只读，继续选择案例、检查和审核。');});
  return id;
}
export function newDefinition(kind:'task'|'solution'|'kc',domainId:string) {
  if(!domain(domainId)) throw Error('请先进入一个有效领域，再创建其中的定义。');
  const id='REV-'+crypto.randomUUID().slice(0,8).toUpperCase();
  const prefix={task:'T',solution:'S',kc:'KC'}[kind];
  const fields:Record<string,string>=kind==='task'?{完成责任:'',参数范围:'',排除范围:''}:kind==='solution'?{适用条件:'',方法:''}:{定义:'',适用范围:''};
  transact(s=>s.issues.unshift({id,title:'新增'+({task:'任务模板',solution:'方法模板',kc:'知识成分'}[kind]),origin:domainId,purpose:'补充明确缺失的领域定义与引用',finding:'',conclusion:'',verdict:'open',proposedNew:true,candidate:{id:`${prefix}-${crypto.randomUUID().slice(0,6).toUpperCase()}`,version:1,kind,space:'Domain',domainId,model:{task:'Task Model',solution:'Solution Model',kc:'Knowledge Component Model'}[kind],name:'',summary:'',status:'draft',source:'管理员候选；尚未审核发布',fields,relations:[],at:new Date().toISOString()},sampleCases:[],impacts:[],log:[{at:new Date().toISOString(),text:'建立新增定义草稿，未写入正式示例目录。'}],dataMode:'demo'}));
  return id;
}
export function saveCandidate(id:string,candidate:ModelObject,samples:string[]) {
  mutateIssue(id,(i,s)=>{
    if(i.dataMode==='real') throw Error('真实会话未采用本示例模型；请勿将其直接关联为示例模型的修改依据。');
    if(i.published) throw Error('已发布候选不可覆盖，请建立新的修订。');
    if(!editableKinds.includes(candidate.kind)&&!i.delivery) throw Error('此类语义规则需通过受控版本交付。');
    if(i.delivery&&JSON.stringify(candidate)!==JSON.stringify(i.candidate))throw Error('规则版本包正文只读；变更内容应重新准备版本包及审核。');
    if(i.candidate && (candidate.id!==i.candidate.id || candidate.kind!==i.candidate.kind || candidate.version!==i.candidate.version || candidate.domainId!==i.candidate.domainId)) throw Error('候选身份与所属领域不可变更。');
    if(i.proposedNew && latest(candidate.id,s)) throw Error('该对象编号已存在，请使用不同编号。');
    i.candidate=clone(candidate);i.sampleCases=[...samples];delete i.check;delete i.approval;log(i,'保存候选及案例范围；此前检查和批准失效。');
  });
}
function signature(i:Issue,s:AdminState=state) {
  const c=i.candidate;
  // Conservative revision fence: the current catalog is small; any normative version change requires a fresh check.
  return JSON.stringify({candidate:c,cases:i.sampleCases,base:c?latest(c.id,s):null,refs:catalog(s).filter(o=>!personalKinds.includes(o.kind)),preparation:s.preparations});
}
export function checkCurrent(i:Issue) { return !!i.check && i.check.signature===signature(i); }
export function checks(candidate:ModelObject,s:AdminState=state):Check[] {
  const effective = (id:string) => id===candidate.id ? candidate : resolve(id,undefined,s);
  const result:Check[]=[{name:'必要定义',passed:!!candidate.name.trim() && !!candidate.summary.trim() && Object.values(candidate.fields).every(x=>!!x.trim()),detail:'名称、说明和已有定义字段不得为空；语义是否正确仍需人工核对。'}];
  if(['task','solution','kc'].includes(candidate.kind)) result.push({name:'领域归属',passed:!!candidate.domainId&&!!domain(candidate.domainId,s),detail:'领域定义必须归属于已建立的领域；不通过教材或学习空间猜测归属。'});
  const missing=candidate.relations.filter(r=>!r.label.trim() || !effective(r.ref));
  result.push({name:'引用存在且版本可解析',passed:!missing.length,detail:missing.length?missing.map(r=>r.ref).join('、'):'所有候选引用均能定位；检查采用当前目录版本。'});
  const expected:Record<string,string[]>={'可用方法':['solution'],'适用任务':['task'],'分解为子任务':['task'],'任务理解依赖':['kc'],'方法依赖':['kc'],'先修知识':['kc'],'映射任务':['task'],'允许方法':['solution'],'采用 Claim':['claim'],'精确绑定任务版本':['task'],'教材章节':['chapter'],'所属材料':['material'],'章节映射':['mapping'],'适用章节':['chapter']};
  const wrong=candidate.relations.filter(r=>expected[r.label] && !expected[r.label]!.includes(effective(r.ref)?.kind||''));
  result.push({name:'关系类型',passed:!wrong.length,detail:wrong.length?wrong.map(r=>`${r.label} → ${r.ref}`).join('；'):'子任务指向 TaskTemplate，知识依赖指向 KC，不将 Solution 当作子任务。'});
  const visited=new Set<string>(), visiting=new Set<string>();
  const cyclic=(id:string):boolean=>{
    if(visiting.has(id)) return true; if(visited.has(id)) return false;
    const o=effective(id); if(!o) return false;
    visiting.add(id);
    const refs=o.relations.filter(r=>['可用方法','分解为子任务','先修知识'].includes(r.label));
    if(refs.some(r=>cyclic(r.ref.split('@')[0]!))) return true;
    visiting.delete(id);visited.add(id);return false;
  };
  result.push({name:'递归依赖无环',passed:!cyclic(candidate.id),detail:'检查 Task → 方法 → 子任务以及 KC 先修依赖；不把反向浏览关系当成循环。'});
  if(['mapping','target'].includes(candidate.kind)) {
    const tasks=candidate.kind==='mapping'?candidate.relations.filter(r=>r.label==='映射任务').map(r=>r.ref.split('@')[0]):candidate.relations.filter(r=>r.label==='采用 Claim').flatMap(r=>effective(r.ref)?.relations.filter(x=>x.label==='精确绑定任务版本').map(x=>x.ref.split('@')[0])||[]);
    const methods=candidate.relations.filter(r=>r.label==='允许方法');
    result.push({name:'任务与方法相容',passed:tasks.length>0 && methods.length>0 && methods.every(r=>effective(r.ref)?.relations.some(x=>x.label==='适用任务' && tasks.includes(x.ref.split('@')[0]))),detail:'所选方法必须用于已选择的任务；方法范围与 Claim 文字条件仍需人工审核。'});
    if(candidate.kind==='target') {
      const claims=candidate.relations.filter(r=>r.label==='采用 Claim').map(r=>effective(r.ref));
      result.push({name:'目标方面已有定义',passed:!!candidate.requiredAspects?.length && claims.length>0 && claims.every(c=>candidate.requiredAspects!.every(k=>c?.aspects?.some(a=>a.key===k && a.applicable))),detail:'目标要求只能选择所采用 Claim 中已定义、适用的方面；裁剪不能反写共享 Claim。'});
    }
  }
  if(candidate.kind==='claim'){
    const binding=candidate.relations.filter(r=>r.label==='精确绑定任务版本');
    result.push({name:'Claim 精确绑定单个任务',passed:binding.length===1 && /^T-[^@]+@\d+$/.test(binding[0]!.ref) && resolve(binding[0]!.ref,undefined,s)?.kind==='task',detail:'Claim 不绑定多任务集合，也不通过修改目标新建个人 Claim。'});
    const aspects=candidate.aspects||[];
    result.push({name:'评价方面可追溯',passed:aspects.length>0&&new Set(aspects.map(a=>a.key)).size===aspects.length&&aspects.every(a=>a.key&&a.criterion&&a.evidence&&(a.applicable||a.reason)),detail:'方面键不重复，定义、证据条件和裁剪依据完整；不适用不等于学生得零分。'});
  }
  return result;
}
function describe(o:ModelObject) { return [o.name,o.summary,...Object.entries(o.fields).map(([k,v])=>k+'：'+v),...o.relations.map(r=>r.label+' → '+r.ref),o.requiredAspects?'目标方面：'+o.requiredAspects.join('、'):''].filter(Boolean).join('\n'); }
export function runChecks(id:string) {
  mutateIssue(id,(i,s)=>{
    if(!i.candidate || i.published) throw Error('请先准备未发布的候选。');
    const baseline=latest(i.candidate.id,s);
    const results=checks(i.candidate,s);
    results.push({name:'修订基线未变化',passed:i.proposedNew?!baseline:baseline?.version===i.baseVersion,detail:'有其他新版时必须重新建立或调整候选，不能覆盖并发修改。'});
    const comparable=(o:ModelObject|undefined)=>JSON.stringify(o&&{name:o.name,summary:o.summary,fields:o.fields,relations:o.relations,requiredAspects:o.requiredAspects});
    results.push({name:'存在实际差异',passed:comparable(i.candidate)!==comparable(baseline),detail:'无内容差异不生成新版本。'});
    results.push({name:'代表性案例已选择',passed:i.sampleCases.length>0 && i.sampleCases.every(id=>s.activities.some(a=>a.id===id)),detail:'请选择已有示例案例，再逐项人工比较；不把结构检查当成语义验证。'});
    if(['mapping','chapter','material','target'].includes(i.candidate.kind)) results.push({name:'章节来源已核对',passed:s.preparations.some(p=>p.reviewed && !!p.note.trim()),detail:'原材料核对记录是本示例发布的前置条件。'});
    i.check={at:new Date().toISOString(),signature:signature(i,s),checks:results,cases:i.sampleCases.map(id=>({id,before:baseline?describe(baseline):'当前无定义',after:describe(i.candidate!),note:'只展示固定事实与候选定义供人工比较；未自动重跑 LLM，也未改写任何学习结果。'}))};
    delete i.approval;log(i,'执行结构与引用检查；案例语义判断待人工记录。');
  });
}
export function reviewCase(id:string,caseId:string,verdict:'pass'|'fail',review:string) {
  mutateIssue(id,(i,s)=>{if(i.published)throw Error('已发布事项的检查记录不能覆盖。');if(!i.check || i.check.signature!==signature(i,s)) throw Error('检查依据已变化，请重新检查。');if(!review.trim()) throw Error('请记录案例核对依据。');const c=i.check.cases.find(c=>c.id===caseId);if(!c) throw Error('案例不存在。');c.verdict=verdict;c.review=review.trim();delete i.approval;log(i,`案例 ${caseId}：${verdict==='pass'?'支持候选':'不支持候选'}，${review.trim()}`);});
}
export function approve(id:string,reason:string) {
  mutateIssue(id,(i,s)=>{
    if(i.published)throw Error('已发布事项不能重新批准覆盖。');
    if(!i.check || i.check.signature!==signature(i,s)) throw Error('检查失效或未执行，请重新检查。');
    if(i.check.checks.some(c=>!c.passed) || i.check.cases.some(c=>c.verdict!=='pass')) throw Error('存在未通过的检查或尚未确认的案例，不能批准。');
    if(!reason.trim()) throw Error('请记录本次审核依据及适用范围。');
    i.approval={at:new Date().toISOString(),reason:reason.trim(),signature:i.check.signature};log(i,'管理员审核批准：'+reason.trim());
  });
}
export function publish(id:string) {
  mutateIssue(id,(i,s)=>{
    if(i.published) throw Error('该候选已经发布。');
    if(!i.candidate || !i.approval || i.approval.signature!==signature(i,s)) throw Error('批准不存在或依据已变化，不能发布。');
    const next=clone(i.candidate);next.status='published';next.at=new Date().toISOString();next.referenceVersions=Object.fromEntries(catalog(s).filter(o=>!personalKinds.includes(o.kind)).map(o=>[o.id,o.version]));next.referenceVersions[next.id]=next.version;s.objects.push(next);i.published=objectKey(next);
    i.impacts=s.spaces.filter(ls=>ls.adopted[next.id]!==undefined).map(ls=>({space:ls.id,status:'pending',detail:'新版已入示例目录；空间仍使用原版本，尚未指定采用。'}));
    log(i,`${objectKey(next)} 已发布到示例目录；未自动更新空间，也未调用真实评价。`);
  });
}
export function adopt(id:string,spaceIds:string[],reason:string) {
  if(!spaceIds.length || !reason.trim()) throw Error('请选择采用空间并记录相容性、范围和影响核对依据。');
  mutateIssue(id,(i,s)=>{
    if(!i.published || !i.candidate) throw Error('必须先发布再指定采用。');
    const c=resolve(i.published,undefined,s)!;
    for(const spaceId of spaceIds) {
      const ls=s.spaces.find(x=>x.id===spaceId);if(!ls) throw Error('学习空间不存在。');
      if(!i.impacts.some(p=>p.space===spaceId)) throw Error('该空间不在本次影响范围。');
      if(ls.adopted[c.id]===c.version) continue;
      if(c.kind==='task' && catalog(s).some(x=>x.kind==='claim' && ls.adopted[x.id]!==undefined && x.relations.some(r=>r.ref===`${c.id}@${ls.adopted[c.id]}`))) throw Error('Task 版本改变，但当前 Claim 仍绑定旧 Task。请先准备相容的 Claim 版本与采用方案，不能直接套用旧能力状态。');
      if(c.kind==='target' && c.id!==ls.target) throw Error('版本更新不能替学生改选目标。');
      const missing=c.relations.filter(r=>!resolve(r.ref,ls.adopted,s));if(missing.length) throw Error('此空间缺少依赖：'+missing.map(r=>r.ref).join('、'));
      const before=clone(ls.adopted);ls.adopted[c.id]=c.version;
      ls.history.push({at:new Date().toISOString(),issueId:id,before,after:clone(ls.adopted),reason:reason.trim()});
      const impact=i.impacts.find(p=>p.space===spaceId)!;
      impact.status='unresolved';impact.detail=c.kind==='target'?'空间已采用新版目标；待正式引擎重算目标评价，未改变原 Belief。':'示例空间已采用新版；历史影响需正式引擎或人工核实，本原型未执行重推断。';
      log(i,`${spaceId} 已采用 ${i.published}；保留所选章节及原始记录。`);
    }
  });
}
export function invalidateEvidence(issueId:string,ref:string,reason:string) {
  if(!reason.trim()) throw Error('请说明停止使用的依据。');
  mutateIssue(issueId,(i,s)=>{
    if(i.verdict!=='confirmed') throw Error('请先记录确认问题成立的复核结论。');
    if(i.dataMode!=='demo' || resolve(ref,undefined,s)?.kind!=='evidence') throw Error('本操作只用于已确认有问题的示例 Evidence。');
    const affected=new Set([ref]);let changed=true;
    while(changed){changed=false;for(const o of s.objects) if(personalKinds.includes(o.kind) && o.relations.some(r=>affected.has(r.ref)) && !affected.has(objectKey(o))){affected.add(objectKey(o));changed=true;}}
    for(const key of affected) s.invalidated[key]=`${i.id}：${reason.trim()}。待重新解释或推断；原历史内容保留。`;
    log(i,'停止当前使用 '+[...affected].join('、')+'；未手动改写 Belief。');
  });
}
export function recordImpact(id:string,spaceId:string,outcome:'none'|'failed'|'unresolved',reason:string) {
  if(!reason.trim())throw Error('请记录影响处理依据，不能只修改状态。');
  mutateIssue(id,(i,s)=>{
    const impact=i.impacts.find(p=>p.space===spaceId);const ls=s.spaces.find(x=>x.id===spaceId);
    if(!impact||!ls||!i.published||!i.candidate)throw Error('影响记录不存在。');
    if(outcome==='none'){
      if(ls.adopted[i.candidate.id]!==i.candidate.version)throw Error('空间尚未采用本版，请先完成采用。');
      if(s.activities.some(a=>a.ls===spaceId&&a.objects.some(ref=>s.invalidated[ref])))throw Error('该空间存在已退出使用的结果，不能声明无需处理。');
      impact.status='done';impact.detail='人工核对：无需历史重处理。'+reason.trim()+'；未执行真实重推断。';
    }else{impact.status=outcome;impact.detail=reason.trim();}
    log(i,`${spaceId} 影响核对：${impact.detail}`);
  });
}
export function readiness(chapter:string,bindings?:Record<string,number>) {
  const prep=state.preparations.find(p=>p.chapter===chapter);
  const ch=resolve(chapter,bindings);const map=ch?.relations.find(r=>r.label==='章节映射');const mapping=map&&resolve(map.ref,bindings);
  const target=ch?.relations.find(r=>r.label==='可选目标');const goal=target&&resolve(target.ref,bindings);
  const validMapping=!!mapping && checks(mapping).every(c=>c.passed);
  const validTarget=!!goal && checks(goal).every(c=>c.passed);
  return [{label:'浏览',ready:!!prep?.reviewed,reason:prep?.reviewed?'来源与章节已核对':'等待原材料核对'},
    {label:'讲解',ready:!!prep?.reviewed && validMapping,reason:validMapping?'示例映射可解析，实际教学质量另行验证':'缺少明确的任务与方法映射'},
    {label:'练习反馈',ready:!!prep?.reviewed && validMapping,reason:'需要原题、参考解法和反馈依据；当前为示例核对结果'},
    {label:'正式评价',ready:!!prep?.reviewed && validMapping && validTarget,reason:validTarget?'示例定义齐备；尚未连接正式评价引擎':'目标或 Claim 条件尚不完整'}];
}
