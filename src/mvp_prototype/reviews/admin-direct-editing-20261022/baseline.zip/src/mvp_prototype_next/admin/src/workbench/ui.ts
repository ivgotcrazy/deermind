import { ref } from 'vue';
export const preview=ref<{ref:string;scope:string}|null>(null);
