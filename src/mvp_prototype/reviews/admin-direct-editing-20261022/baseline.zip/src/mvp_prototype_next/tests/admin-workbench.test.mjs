import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, rm, writeFile, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { once } from 'node:events';
import { chromium } from '../../mvp_prototype/node_modules/playwright/index.mjs';
import { expect } from '../../mvp_prototype/node_modules/@playwright/test/index.mjs';
import { createPrototypeServer } from '../scripts/serve.mjs';

const output=fileURLToPath(new URL('../../../.tmp/mvp-prototype-next/admin-workbench-review/',import.meta.url));
const key='deermind-next-admin-workbench-v1';
await mkdir(output,{recursive:true});
test('administrator workflows, isolation, invalidation and scalable navigation',async t=>{
  const directory=await mkdtemp(path.join(tmpdir(),'deermind-admin-ui-'));
  const server=createPrototypeServer({directory,config:{key:'test',model:'fixture'},provider:async()=>{throw Error('No model call expected');}});
  server.listen(0,'127.0.0.1');await once(server,'listening');
  const base=`http://127.0.0.1:${server.address().port}/admin/`;
  const browser=await chromium.launch({headless:true,channel:'msedge'});
  t.after(async()=>{await browser.close();await new Promise(r=>server.close(r));await rm(directory,{recursive:true,force:true});});
  async function context(){const ctx=await browser.newContext({viewport:{width:1440,height:1000},locale:'zh-CN'});const p=await ctx.newPage();p.setDefaultTimeout(8000);const errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(base);await expect(p.getByRole('heading',{name:'运行总览',exact:true})).toBeVisible();return {ctx,p,errors};}
  async function visit(p,hash){await p.goto(base+hash);}
  async function grant(p){const gate=p.locator('.access-gate').first();if(await gate.isVisible()){await gate.getByLabel('用途',{exact:true}).fill('作者走查：核对当前记录与模型依据');await gate.getByRole('button',{name:'记录用途并查看'}).click();await expect(gate).not.toBeVisible();}}
  async function stored(p){return p.evaluate(k=>JSON.parse(localStorage.getItem(k)),key);}
  async function checkAndApprove(p){await p.getByRole('button',{name:'检查结果',exact:true}).click();await p.getByRole('button',{name:'执行检查',exact:true}).click();await expect(p.getByText('存在实际差异',{exact:true})).toBeVisible();await p.getByLabel('案例判断',{exact:true}).selectOption('pass');await p.getByLabel('比较依据与局限',{exact:true}).fill('核对固定题意、参照量与实际帮助。候选在所选案例可用，不推断普遍语义正确。');await p.getByRole('button',{name:'保存此案例判断'}).click();await p.getByRole('button',{name:'审核发布',exact:true}).click();await p.getByLabel('审核依据和批准范围').fill('仅批准当前章节及已有方法范围；保留旧记录，发布后另行指定采用。');await p.getByRole('button',{name:'记录审核批准'}).click();await expect(p.getByRole('button',{name:'发布到示例目录'})).toBeEnabled();}
  await t.test('prepare chapter, publish mapping and adopt only one space',async()=>{
    const {ctx,p,errors}=await context();
    await p.getByRole('button',{name:'准备一个章节'}).click();await p.getByLabel('核对结果与剩余疑点').fill('已核对两题的数值、单位、参照量和参考解法；仅为合成章节。');await p.getByRole('button',{name:'保存核对结果'}).click();
    await p.getByRole('button',{name:'2 模型映射'}).click();await p.screenshot({path:path.join(output,'chapter-mapping.png'),fullPage:true});await p.getByRole('button',{name:'修订映射与允许方法'}).click();await grant(p);
    await p.getByLabel('定义说明',{exact:true}).fill('明确映射第一题和第二题；保留允许的算术及方程方法，超出范围另行审核。');await p.getByLabel('ACT-001 · 提示后完成原量增减题').check();await p.getByRole('button',{name:'保存候选与案例范围'}).click();await checkAndApprove(p);
    await p.getByRole('button',{name:'发布到示例目录'}).click();let s=await stored(p);assert.equal(s.spaces[0].adopted['MAP-001'],1);assert.equal(s.objects.filter(o=>o.id==='MAP-001').length,2);
    await p.getByRole('button',{name:'检查并指定空间采用'}).click();await p.getByRole('checkbox',{name:'采用到 LS-001',exact:true}).check();await p.getByLabel('相容性与影响核对').fill('仅更新 LS-001；任务、方法和目标相容，章节选择不变；历史影响保留待处理。');await p.getByRole('button',{name:'指定所选空间采用'}).click();
    s=await stored(p);assert.equal(s.spaces[0].adopted['MAP-001'],2);assert.equal(s.spaces[1].adopted['MAP-001'],1);assert.equal(s.activities[0].versions['MAP-001'],1);assert.equal(s.issues[0].impacts[0].status,'unresolved');
    await p.reload();await expect(p.getByText('示例空间已采用新版；历史影响需正式引擎或人工核实，本原型未执行重推断。')).toBeVisible();await p.screenshot({path:path.join(output,'release-adoption.png'),fullPage:true});assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('inspect prompted answer, confirm issue, invalidate dependents without overwriting facts or beliefs',async()=>{
    const {ctx,p,errors}=await context();await visit(p,'#/activity?id=ACT-001&scope=ACT-001');await grant(p);await expect(p.getByText('把 80 升当作原量，先算 80 × 1/4，再加回 80。',{exact:true})).toBeVisible();
    await p.getByRole('button',{name:'评价依据',exact:true}).click();await expect(p.getByText('独立完成',{exact:true}).first()).toBeVisible();const before=await stored(p);
    await p.getByRole('button',{name:'建立复核事项',exact:true}).click();await p.getByLabel('预期、实际差异与核对目的').fill('提示已经实际展示，核对独立完成支持是否遗漏帮助条件。');await p.getByRole('button',{name:'建立并查看事项'}).click();await grant(p);
    await p.getByLabel('核对事实',{exact:true}).fill('F-002 已展示列式，早于 F-003 作答；EV-001 忽略该事实。');await p.getByLabel('复核结论',{exact:true}).selectOption('confirmed');await p.getByLabel('判断依据与后续方向').fill('确认示例 EV-001 的独立支持不成立，停止作为当前依据并等待重新解释。');await p.getByRole('button',{name:'保存复核意见'}).click();await p.getByRole('button',{name:'停止使用此依据及依赖结果'}).click();
    const after=await stored(p);assert.ok(after.invalidated['EV-001@1']);assert.ok(after.invalidated['BL-001@1']);assert.ok(after.invalidated['TA-001@1']);assert.ok(!after.invalidated['BL-002@1']);assert.deepEqual(before.activities,after.activities);assert.deepEqual(before.objects,after.objects);
    await p.getByLabel('在本事项中修订定义').selectOption('S-001@1');await p.getByRole('button',{name:'关联候选，保留本次复核依据'}).click();await expect(p.getByLabel('名称',{exact:true})).toHaveValue('原量加减变化量');assert.equal((await stored(p)).issues[0].origin,'ACT-001');
    await visit(p,'#/students?id=ST-001&scope=LS-001');await grant(p);await expect(p.getByText('已退出当前使用，待重新推断。原判断仅作历史查看。')).toBeVisible();await p.screenshot({path:path.join(output,'student-aspects.png'),fullPage:true});assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('bad relation blocks publish; edited candidate invalidates approval; references survive reload',async()=>{
    const {ctx,p,errors}=await context();await visit(p,'#/object?id=S-001%401');await p.getByRole('button',{name:'创建修订',exact:true}).click();await grant(p);
    await p.getByLabel('适用条件',{exact:true}).fill('已知正的原量 V；减少比例严格小于 1；求变化后的量。');await p.getByLabel('ACT-001 · 提示后完成原量增减题').check();
    const refs=p.getByRole('textbox',{name:'引用对象',exact:true});await refs.nth(1).fill('S-001');await p.getByRole('button',{name:'保存候选与案例范围'}).click();await p.getByRole('button',{name:'检查结果',exact:true}).click();await p.getByRole('button',{name:'执行检查',exact:true}).click();await expect(p.getByText('未通过',{exact:true}).first()).toBeVisible();
    await p.getByRole('button',{name:'候选差异',exact:true}).click();await refs.nth(1).fill('T-003');await p.getByRole('button',{name:'保存候选与案例范围'}).click();await checkAndApprove(p);await p.getByRole('button',{name:'候选差异',exact:true}).click();await p.getByLabel('定义说明',{exact:true}).fill('另一次改动，旧批准必须失效。');await p.getByRole('button',{name:'保存候选与案例范围'}).click();await p.getByRole('button',{name:'审核发布',exact:true}).click();await expect(p.getByRole('button',{name:'发布到示例目录'})).toBeDisabled();assert.equal((await stored(p)).issues[0].approval,undefined);
    await visit(p,'#/domain?domain=DOM-MATH&q=原量&filter=task&p=1');await p.getByRole('button',{name:'已知原量与增减分率，求变化后的量',exact:true}).click();await p.reload();await expect(p.getByRole('heading',{name:'已知原量与增减分率，求变化后的量',exact:true})).toBeVisible();await p.getByRole('button',{name:'关联关系',exact:true}).click();await p.getByRole('button',{name:/原量加减变化量 v1/}).click();await expect(p.getByRole('dialog')).toBeVisible();await p.getByRole('button',{name:/求一个量的几分之几 v1/}).click();await expect(p.getByRole('dialog').getByRole('heading',{name:'求一个量的几分之几',exact:true})).toBeVisible();await p.getByRole('button',{name:'关闭对话框'}).click();await p.screenshot({path:path.join(output,'task-relations.png'),fullPage:true});
    assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('real sessions remain distinct, unavailable evaluation is explicit, list is read-only',async()=>{
    const {ctx,p,errors}=await context();const sample={version:2,revision:1,id:'NEXT-admin-real-fixture',scope:{space:'math-6b',label:'六年级下册数学'},model:'fixture',phase:'learning',pending:null,error:null,createdAt:'2026-10-21',updatedAt:'2026-10-21',turns:[{id:'t1',role:'user',text:'为什么圆柱体积是底面积乘高？',displayText:'为什么圆柱体积是底面积乘高？',action:'message',at:'2026-10-21'}],requests:{}};await writeFile(path.join(directory,sample.id+'.json'),JSON.stringify(sample));
    await p.getByLabel('数据来源',{exact:true}).selectOption('real');await p.getByRole('button',{name:'交互审查',exact:true}).click();await expect(p.getByRole('button',{name:'为什么圆柱体积是底面积乘高？',exact:true})).toBeVisible();await p.getByRole('button',{name:'为什么圆柱体积是底面积乘高？',exact:true}).click();await grant(p);await expect(p.getByText(/此记录尚未绑定正式学生身份/)).toBeVisible();await p.reload();await expect(p.getByRole('heading',{name:'真实会话 · NEXT-admin-real-fixture'})).toBeVisible();await p.getByRole('button',{name:'学生状态',exact:true}).click();await expect(p.getByText(/当前真实对话没有正式学生身份/)).toBeVisible();await p.screenshot({path:path.join(output,'real-no-fake-belief.png'),fullPage:true});assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('controlled semantic package remains read-only and follows review before adoption',async()=>{
    const {ctx,p,errors}=await context();await visit(p,'#/object?id=ER-001%401');
    const download=p.waitForEvent('download');await p.getByRole('button',{name:'导出候选版本包模板'}).click();const file=await download;const pkg=JSON.parse(await readFile(await file.path(),'utf8'));pkg.object.fields.独立完成+=' 本次交付补充：明确实质帮助必须与作答时间核对。';
    await p.getByLabel('导入语义定义版本包').setInputFiles({name:'ER-001-v2.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(pkg))});await expect(p).toHaveURL(/maintenance/);await grant(p);await expect(p.getByLabel('名称',{exact:true})).toBeDisabled();
    await p.getByLabel('ACT-001 · 提示后完成原量增减题').check();await p.getByRole('button',{name:'保存候选与案例范围'}).click();await checkAndApprove(p);await p.getByRole('button',{name:'发布到示例目录'}).click();const s=await stored(p);assert.equal(s.objects.filter(o=>o.id==='ER-001').length,2);assert.equal(s.spaces[0].adopted['ER-001'],1);assert.ok(s.issues[0].delivery);assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('large catalogs paginate; source query and exact object survive back and refresh',async()=>{
    const {ctx,p,errors}=await context();await visit(p,'#/activity?id=ACT-003&scope=ACT-003');await grant(p);await p.evaluate(k=>{const s=JSON.parse(localStorage.getItem(k));const template=s.objects.find(o=>o.id==='T-001');for(let n=0;n<125;n++)s.objects.push({...template,id:'T-SCALE-'+String(n).padStart(3,'0'),name:'规模走查任务 '+n,source:'仅浏览器压力样本'});localStorage.setItem(k,JSON.stringify(s));},key);await p.reload();
    await visit(p,'#/domain?domain=DOM-MATH&filter=task&q=规模走查&p=1');await expect(p.locator('.data-table tbody tr')).toHaveCount(10);await p.getByRole('button',{name:'下一页',exact:true}).click();await expect(p.getByRole('button',{name:'规模走查任务 10',exact:true})).toBeVisible();await p.getByRole('button',{name:'规模走查任务 10',exact:true}).click();await p.reload();await expect(p.getByRole('heading',{name:'规模走查任务 10',exact:true})).toBeVisible();await p.getByRole('button',{name:'← 返回来源',exact:true}).click();assert.ok(p.url().includes('p=2'));await expect(p.locator('.data-table tbody tr')).toHaveCount(10);
    await p.setViewportSize({width:1024,height:768});await p.screenshot({path:path.join(output,'catalog-125-compact.png'),fullPage:true});const overflow=await p.locator('.page-container').evaluate(el=>el.scrollWidth>el.clientWidth+2);assert.equal(overflow,false);
    await visit(p,'#/object?id=NO-SUCH-OBJECT%401');await expect(p.getByRole('heading',{name:'没有可解析的对象版本'})).toBeVisible();assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('concurrent editing refuses stale writes instead of overwriting another window',async()=>{
    const {ctx,p,errors}=await context();const second=await ctx.newPage();second.setDefaultTimeout(8000);await visit(p,'#/textbooks?id=CH-001');await visit(second,'#/textbooks?id=CH-001');await p.getByLabel('核对结果与剩余疑点').fill('窗口一已核对，必须保留。');await p.getByRole('button',{name:'保存核对结果'}).click();await second.getByLabel('核对结果与剩余疑点').fill('窗口二旧版本写入。');await second.getByRole('button',{name:'保存核对结果'}).click();await expect(second.getByRole('alert')).toContainText('另一窗口已更新');assert.equal((await stored(p)).preparations[0].note,'窗口一已核对，必须保留。');assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('create domain validates input, preserves cancel, restores scope and creates isolated objects',async()=>{
    const {ctx,p,errors}=await context();await visit(p,'#/domain');
    await expect(p.getByRole('button',{name:'新建领域',exact:true})).toBeVisible();
    await p.getByRole('button',{name:'新建领域',exact:true}).click();
    await p.getByLabel('领域名称',{exact:true}).fill('不会保存');await p.getByRole('button',{name:'取消',exact:true}).click();
    await expect(p.getByRole('dialog')).toHaveCount(0);await expect(p.getByRole('button',{name:'不会保存',exact:true})).toHaveCount(0);
    await p.getByRole('button',{name:'新建领域',exact:true}).click();
    await p.getByLabel('领域名称',{exact:true}).fill('   ');await p.getByLabel('覆盖范围',{exact:true}).fill('范围');await p.getByRole('button',{name:'创建并进入'}).click();
    await expect(p.getByRole('dialog').getByRole('alert')).toContainText('请填写领域名称');
    await p.getByLabel('领域名称',{exact:true}).fill('数学');await p.getByRole('button',{name:'创建并进入'}).click();await expect(p.getByRole('dialog').getByRole('alert')).toContainText('同名领域');
    await p.getByLabel('领域名称',{exact:true}).fill('分数应用实验域');await p.getByLabel('覆盖范围',{exact:true}).fill('正原量与增减分率之间的数量关系。');await p.getByLabel('说明（选填）').fill('用于作者隔离检查，不是真实教材。');await expect(p.getByRole('dialog').getByRole('alert')).toHaveCount(0);await p.screenshot({path:path.join(output,'domain-create.png'),fullPage:true});
    await p.getByRole('button',{name:'创建并进入'}).click();await expect(p.getByRole('heading',{name:'分数应用实验域',exact:true})).toBeVisible();
    const id=new URLSearchParams(p.url().split('?')[1]).get('domain');assert.ok(id?.startsWith('DOM-'));
    await p.reload();await expect(p.getByRole('heading',{name:'分数应用实验域',exact:true})).toBeVisible();await expect(p.locator('.data-table tbody tr')).toHaveCount(0);
    await p.getByRole('button',{name:'新增任务模板',exact:true}).click();await grant(p);await p.getByLabel('名称',{exact:true}).fill('识别分率所指的原量');await p.getByLabel('定义说明',{exact:true}).fill('从已知数量和增减分率中说明哪个量作为比较基础。');
    await p.getByLabel('完成责任',{exact:true}).fill('识别原量并说明理由');await p.getByLabel('参数范围',{exact:true}).fill('正原量；减少比例小于 1');await p.getByLabel('排除范围',{exact:true}).fill('不涉及多次连续变化');await p.getByLabel('ACT-001 · 提示后完成原量增减题').check();await p.getByRole('button',{name:'保存候选与案例范围'}).click();
    let s=await stored(p);const issueId=s.issues[0].id;const taskId=s.issues[0].candidate.id;assert.equal(s.issues[0].candidate.domainId,id);
    await visit(p,'#/domain?domain='+id);await expect(p.getByRole('heading',{name:'未发布候选（1）'})).toBeVisible();await p.getByRole('button',{name:'识别分率所指的原量',exact:true}).click();await grant(p);
    await checkAndApprove(p);await p.getByRole('button',{name:'发布到示例目录'}).click();s=await stored(p);assert.equal(s.objects.find(o=>o.id===taskId).domainId,id);assert.equal(s.issues.find(i=>i.id===issueId).impacts.length,0);
    for(const [kind,label]of [['solution','方法模板'],['kc','知识成分']]){
      await visit(p,'#/domain?domain='+id+'&filter='+kind);await p.getByRole('button',{name:'新增'+label,exact:true}).click();await grant(p);assert.equal((await stored(p)).issues[0].candidate.domainId,id);await p.getByRole('button',{name:'分数应用实验域',exact:true}).click();await expect(p.getByLabel('对象类型',{exact:true})).toHaveValue(kind);
    }
    await visit(p,'#/domain?domain='+id);await expect(p.locator('.data-table tbody tr')).toHaveCount(1);await p.screenshot({path:path.join(output,'domain-scoped-task.png'),fullPage:true});
    await visit(p,'#/domain?domain=DOM-MATH');await expect(p.getByRole('button',{name:'识别分率所指的原量',exact:true})).toHaveCount(0);
    await visit(p,'#/domain');const row=p.locator('.data-table tbody tr').filter({has:p.getByRole('button',{name:'分数应用实验域',exact:true})});await expect(row.locator('td').nth(2)).toHaveText('1');await expect(row.locator('td').nth(3)).toHaveText('0');
    assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('legacy records migrate without guessing unknown domains or changing facts and versions',async()=>{
    const {ctx,p,errors}=await context();await visit(p,'#/domain?domain=DOM-MATH');await p.getByRole('button',{name:'新增任务模板',exact:true}).click();await grant(p);
    await p.getByLabel('名称',{exact:true}).fill('旧草稿，保留');await p.getByRole('button',{name:'保存候选与案例范围'}).click();
    const legacy=await p.evaluate(k=>{const s=JSON.parse(localStorage.getItem(k));s.schema=1;delete s.domains;s.objects.forEach(o=>delete o.domainId);s.issues.forEach(i=>{if(i.candidate)delete i.candidate.domainId;});const raw=JSON.stringify(s);localStorage.setItem(k,raw);return raw;},key);
    await p.reload();await visit(p,'#/domain');await expect(p.getByRole('button',{name:'待归类的历史定义',exact:true})).toBeVisible();
    assert.equal(await p.evaluate(k=>localStorage.getItem(k+'.before-domains'),key),legacy);
    await p.getByRole('button',{name:'新建领域',exact:true}).click();await p.getByLabel('领域名称',{exact:true}).fill('厨艺');await p.getByLabel('覆盖范围',{exact:true}).fill('基础食材处理与烹饪操作');await p.getByRole('button',{name:'创建并进入'}).click();
    const upgraded=await stored(p),before=JSON.parse(legacy);assert.equal(upgraded.schema,2);assert.deepEqual(upgraded.activities,before.activities);assert.deepEqual(upgraded.spaces,before.spaces);assert.deepEqual(upgraded.invalidated,before.invalidated);
    assert.deepEqual(upgraded.objects.map(({domainId,...o})=>o),before.objects);assert.deepEqual(upgraded.issues.map(i=>({...i,candidate:((({domainId,...o})=>o)(i.candidate))})),before.issues);
    assert.ok(upgraded.objects.filter(o=>['task','solution','kc'].includes(o.kind)).every(o=>o.domainId==='DOM-MATH'));assert.equal(upgraded.issues[0].candidate.domainId,'DOM-LEGACY');
    await visit(p,'#/domain?domain=DOM-LEGACY');await p.getByRole('button',{name:'旧草稿，保留',exact:true}).click();await grant(p);await expect(p.getByLabel('名称',{exact:true})).toHaveValue('旧草稿，保留');assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('domain directory is bounded and searchable with durable return context and explicit missing domains',async()=>{
    const {ctx,p,errors}=await context();await visit(p,'#/textbooks?id=CH-001');await p.getByLabel('核对结果与剩余疑点').fill('为目录规模检查保留既有工作');await p.getByRole('button',{name:'保存核对结果'}).click();
    await p.evaluate(k=>{const s=JSON.parse(localStorage.getItem(k));for(let i=0;i<120;i++)s.domains.push({id:'D-SCALE-'+i,name:'规模领域 '+i,scope:'目录规模检查',description:'',createdAt:'2026-10-21'});localStorage.setItem(k,JSON.stringify(s));},key);
    await p.reload();await visit(p,'#/domain?q=规模领域');await expect(p.locator('.data-table tbody tr')).toHaveCount(10);await p.getByRole('button',{name:'下一页',exact:true}).click();await p.getByRole('button',{name:'规模领域 10',exact:true}).click();await p.reload();await expect(p.getByRole('heading',{name:'规模领域 10',exact:true})).toBeVisible();await p.getByRole('button',{name:'← 返回领域列表',exact:true}).click();await expect(p.getByLabel('搜索领域')).toHaveValue('规模领域');assert.ok(p.url().includes('p=2'));
    await p.setViewportSize({width:1024,height:768});await p.screenshot({path:path.join(output,'domain-list-compact.png'),fullPage:true});assert.equal(await p.locator('.page-container').evaluate(el=>el.scrollWidth>el.clientWidth+2),false);
    await visit(p,'#/domain?domain=DOES-NOT-EXIST');await expect(p.getByRole('heading',{name:'领域不存在',exact:true})).toBeVisible();await expect(p.getByRole('button',{name:'新增任务模板',exact:true})).toHaveCount(0);assert.deepEqual(errors,[]);await ctx.close();
  });
  await t.test('domain creation rejects stale-window writes without losing the created domain',async()=>{
    const {ctx,p,errors}=await context();await visit(p,'#/domain');const second=await ctx.newPage();await visit(second,'#/domain');
    for(const [page,name]of [[p,'厨艺'],[second,'花艺']]){await page.getByRole('button',{name:'新建领域',exact:true}).click();await page.getByLabel('领域名称',{exact:true}).fill(name);await page.getByLabel('覆盖范围',{exact:true}).fill('仅用于并发创建检查');}
    await p.getByRole('button',{name:'创建并进入'}).click();await second.getByRole('button',{name:'创建并进入'}).click();await expect(second.getByRole('dialog').getByRole('alert')).toContainText('另一窗口已更新');
    assert.equal((await stored(p)).domains.filter(d=>['厨艺','花艺'].includes(d.name)).length,1);assert.deepEqual(errors,[]);await ctx.close();
  });
});
